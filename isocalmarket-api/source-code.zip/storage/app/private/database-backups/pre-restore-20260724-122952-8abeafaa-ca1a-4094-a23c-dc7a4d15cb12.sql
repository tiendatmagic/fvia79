-- Isocalmarket MySQL backup
-- Generated at: 2026-07-24T12:29:53+07:00

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: isocalmarket
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `normalized_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  UNIQUE KEY `categories_supplier_id_external_id_unique` (`supplier_id`,`external_id`),
  KEY `categories_normalized_name_index` (`normalized_name`),
  CONSTRAINT `categories_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES ('019f82af-5c43-710f-85e6-ff318e943418','019f829a-f708-7093-890d-4950e6ce2e66','1','BM50$','ads7979-1-bm50',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','bm50$'),('019f82af-5c5e-7396-95a3-825ffab2f738','019f829a-f708-7093-890d-4950e6ce2e66','13','BM3 Limit 50$','ads7979-13-bm3-limit-50',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','bm3 limit 50$'),('019f82af-5c77-72e6-bc4a-a959ae12bf0f','019f829a-f708-7093-890d-4950e6ce2e66','2','Via Kháng 902 & Chat Support','ads7979-2-via-khang-902-chat-support',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','via khang 902 & chat support'),('019f82af-5cad-7392-9656-9f8fa2545c95','019f829a-f708-7093-890d-4950e6ce2e66','3','Ad account Limit 50$','ads7979-3-ad-account-limit-50',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','ad account limit 50$'),('019f82af-5cbe-73f0-b751-0cadcb5c6b36','019f829a-f708-7093-890d-4950e6ce2e66','4','Ad account Limit 250$','ads7979-4-ad-account-limit-250',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','ad account limit 250$'),('019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','019f829a-f708-7093-890d-4950e6ce2e66','5','Via Ngoại Live Ads (No2FA)','ads7979-5-via-ngoai-live-ads-no2fa',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','via ngoai live ads (no2fa)'),('019f82af-5d6c-71c4-a32c-db49989a6cc3','019f829a-f708-7093-890d-4950e6ce2e66','6','Via Ngoại Live Ads (2FA)','ads7979-6-via-ngoai-live-ads-2fa',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','via ngoai live ads (2fa)'),('019f82af-5dea-7360-936b-3aa19da2dd52','019f829a-f708-7093-890d-4950e6ce2e66','9','Via Ngoại DIE ADS','ads7979-9-via-ngoai-die-ads',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','via ngoai die ads'),('019f82af-5e0e-729a-a8e2-59ef4d9e2997','019f829a-f708-7093-890d-4950e6ce2e66','7','Clone Global','ads7979-7-clone-global',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','clone global'),('019f82af-5e4d-730c-994f-86a322e0e883','019f829a-f708-7093-890d-4950e6ce2e66','8','Clone Việt Nam','ads7979-8-clone-viet-nam',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','clone viet nam'),('019f82af-5e56-7144-8a42-34ec76467805','019f829a-f708-7093-890d-4950e6ce2e66','10','Hotmail Live V.V','ads7979-10-hotmail-live-vv',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','hotmail live v.v'),('019f82af-5e67-7153-9ee1-9c332fc1fd73','019f829a-f708-7093-890d-4950e6ce2e66','11','Clone Instagram','ads7979-11-clone-instagram',NULL,1,'2026-07-20 20:19:18','2026-07-20 20:19:18','clone instagram'),('019f846e-67ec-730a-a840-1921ffd184ea','019f846e-66a7-7247-bb63-b9ebcf11be46','1','BM50$','vlclone-1-bm50',NULL,1,'2026-07-21 04:27:35','2026-07-21 04:27:35','bm50$'),('019f846e-6950-7188-871e-a42e435bdd7a','019f846e-66a7-7247-bb63-b9ebcf11be46','2','BM3 Limit 50$','vlclone-2-bm3-limit-50',NULL,1,'2026-07-21 04:27:36','2026-07-21 04:27:36','bm3 limit 50$'),('019f846e-6961-718a-8064-38133070094e','019f846e-66a7-7247-bb63-b9ebcf11be46','3','BM Limit 250$','vlclone-3-bm-limit-250',NULL,1,'2026-07-21 04:27:36','2026-07-21 04:27:36','bm limit 250$'),('019f9224-e6cd-73cb-80c5-2da6a30b5f4e',NULL,NULL,'Danh mục A','danh-muc-a',NULL,0,'2026-07-24 03:21:59','2026-07-24 03:49:44','danh muc a');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `value` decimal(15,2) NOT NULL DEFAULT '10.00',
  `min_spend` decimal(15,2) NOT NULL DEFAULT '0.00',
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `usage_limit` int NOT NULL DEFAULT '1',
  `used_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`),
  KEY `coupons_code_index` (`code`),
  KEY `coupons_start_date_index` (`start_date`),
  KEY `coupons_end_date_index` (`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES ('019f7d72-0a49-7030-931e-baad3df17791','2072026','fixed',10000.00,0.00,'2026-07-20 00:00:00','2026-07-27 00:00:00',1,1,'2026-07-19 19:54:13','2026-07-23 13:12:08','2026-07-23 13:12:08'),('019f7d84-ad34-706a-9b7f-69698e11dd79','20720261','percentage',20.00,500000.00,'2026-07-20 00:00:00','2026-07-27 00:00:00',2,2,'2026-07-19 20:14:34','2026-07-19 20:47:55',NULL),('019f8d69-b3ec-7200-a32b-0fdd20931d43','125333','percentage',10.00,0.00,'2026-07-23 12:18:00','2026-08-22 23:59:00',1,0,'2026-07-22 22:19:02','2026-07-22 22:19:02',NULL);
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposits`
--

DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposits` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_usdt` decimal(16,4) NOT NULL,
  `amount_to_pay` decimal(16,4) NOT NULL,
  `amount_vnd` decimal(16,4) NOT NULL,
  `tx_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_wallet_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_payment',
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bep20',
  `payer_binance_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_binance_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deposits_tx_hash_unique` (`tx_hash`),
  KEY `deposits_user_id_status_index` (`user_id`,`status`),
  KEY `deposits_created_at_index` (`created_at`),
  KEY `deposits_code_index` (`code`),
  KEY `deposits_payer_binance_id_payment_method_index` (`payer_binance_id`,`payment_method`),
  KEY `deposits_status_amount_to_pay_index` (`status`,`amount_to_pay`),
  CONSTRAINT `deposits_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposits`
--

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` VALUES ('019f7d72-53e8-71b5-ac64-cf69cc440163','019f7d2f-cf44-723f-8c30-13b7ea78dadb','GUKXCJ',100.0000,100.0000,2624000.0000,'manual_approved_by_admin_019f7d72-53e8-71b5-ac64-cf69cc440163','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','completed','bep20',NULL,NULL,'2026-07-19 19:54:32','2026-07-19 19:54:45'),('019f7da5-35a9-707b-b805-a6cde36a32ad','019f7d2f-cf44-723f-8c30-13b7ea78dadb','G6XGUJ',0.1500,0.1500,3941.0000,'443847639186710528',NULL,'completed','binance',NULL,'63596652','2026-07-19 20:50:07','2026-07-19 20:59:55'),('019f7e0c-c918-7033-8977-bafe87a4109c','019f7d2f-cf44-723f-8c30-13b7ea78dadb','BL68PV',3.0000,3.0000,78816.0000,'manual_approved_by_admin_019f7e0c-c918-7033-8977-bafe87a4109c','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','completed','bep20',NULL,NULL,'2026-07-19 22:43:14','2026-07-20 13:55:03'),('019f814f-f3f1-70a3-bd2d-3bc15e47340f','019f7d2f-cf44-723f-8c30-13b7ea78dadb','QFNTNG',10000.0000,10000.0000,262760000.0000,'manual_approved_by_admin_019f814f-f3f1-70a3-bd2d-3bc15e47340f','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','completed','bep20',NULL,NULL,'2026-07-20 13:55:28','2026-07-20 13:56:54'),('019f8165-d0e0-71b6-8369-d24e97a121e4','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ZW2CAM',10.0000,10.0000,262750.0000,'22222222222222222222222','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','completed','bep20',NULL,NULL,'2026-07-20 14:19:21','2026-07-20 14:19:46'),('019f8169-0d06-7391-b0a1-373cd71325df','019f7d2f-cf44-723f-8c30-13b7ea78dadb','V2FPWH',100.0000,100.0000,2627500.0000,NULL,'0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','expired','bep20',NULL,NULL,'2026-07-20 14:22:53','2026-07-20 19:15:45'),('019f8275-52c3-72ca-a490-d5fb768917d0','019f7d2f-cf44-723f-8c30-13b7ea78dadb','RW53BD',1.0000,1.0000,26281.0000,NULL,NULL,'expired','binance',NULL,'63596652','2026-07-20 19:15:54','2026-07-22 11:13:19'),('019f858d-d950-73b3-ad5c-5988cf8068f0','019f8489-b459-702d-956a-a183467607c4','Y46UJS',0.1200,0.1200,3156.0000,'0x238b53fffbb6b862ea8ceaddbd95975ce7530eca3bcb56e6aa9afcb2ecc8342c','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','completed','bep20',NULL,NULL,'2026-07-21 09:41:33','2026-07-21 09:47:29'),('019f8593-9631-728d-b89e-bf38680b1cd7','019f8489-b459-702d-956a-a183467607c4','QNWXAZ',0.1400,0.1400,3682.0000,'0x0724681d8390ea248c66726f880fabd91b42e8480750d79da2006185468ec5b5','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','completed','bep20',NULL,NULL,'2026-07-21 09:47:49','2026-07-21 09:57:40'),('019f859c-f43e-703e-909f-16cd0fd7a1cc','019f8489-b459-702d-956a-a183467607c4','M7XKTB',0.2200,0.2200,5786.0000,'0x01ebe80f64a229651ca54f8267851214bb4fb4489244e3761ba75abaad927295','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','revoked','bep20',NULL,NULL,'2026-07-21 09:58:03','2026-07-22 11:17:54'),('019f8b08-5493-70fe-b0d8-56485e7a8b2f','019f7d2f-cf44-723f-8c30-13b7ea78dadb','FSXQ2P',10.0000,10.0000,262970.0000,'manual_approved_by_admin_accept1','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','revoked','bep20',NULL,NULL,'2026-07-22 11:13:26','2026-07-22 11:17:54');
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faqs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_vi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_vi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faqs_is_active_index` (`is_active`),
  KEY `faqs_sort_order_index` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,'Thời gian tiếp nhận và xử lý yêu cầu bảo hành là bao lâu?','How long does it take to process a warranty request?','Thời gian xử lý bảo hành thông thường từ 15 phút đến tối đa 24 giờ làm việc. Kỹ thuật viên sẽ kiểm tra tài khoản theo đúng khung giờ và điều kiện bảo hành.','Standard warranty processing time ranges from 15 minutes up to 24 business hours. Technicians check accounts strictly based on conditions.',1,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(2,'Làm thế nào để gửi yêu cầu bảo hành đơn hàng đã mua?','How can I submit a warranty claim for a purchased order?','Quý khách vui lòng truy cập trang \"Lịch sử đơn hàng\", bấm vào đơn hàng tương ứng và nhấn nút \"Yêu cầu bảo hành\" hoặc liên hệ trực tiếp với bộ phận Chăm sóc khách hàng qua Telegram/Zalo kèm Mã đơn hàng.','Please visit \"Order History\", select your order and click \"Request Warranty\" or contact CS directly via Telegram/Zalo with your Order ID.',2,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(3,'Trường hợp nào tài khoản sẽ bị từ chối bảo hành?','In what scenarios will a warranty claim be rejected?','Tài khoản bị từ chối bảo hành khi: Quá thời hạn bảo hành quy định, đã thay đổi thông tin (Email/Mật khẩu/2FA) đối với các loại tài khoản chưa được phép, sử dụng IP bẩn/bị đen, vi phạm chính sách của Facebook sau khi đã nhận bàn giao thành công.','Warranty is rejected if: exceeded time limit, unauthorized info modification (Email/Password/2FA), dirty/blacklisted IP usage, or Facebook policy violations after delivery.',3,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(4,'Chính sách bảo hành BM xác minh doanh nghiệp (Business Verification)?','What is the policy for Business Verified BMs?','BM xác minh doanh nghiệp được bảo hành 07 ngày đối với các lỗi liên quan đến trạng thái xác minh bị mất hoặc link gia nhập không hoạt động. Không bảo hành trường hợp BM chết do lên camp vi phạm chính sách hoặc add thẻ bẩn.','Verified BMs have a 07-day warranty for lost verification status or broken join links. No warranty for dead BM caused by policy-violating ads or bad payment cards.',4,1,'2026-07-24 04:09:29','2026-07-24 04:09:29');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_batches`
--

DROP TABLE IF EXISTS `inventory_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_batches` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_count` int NOT NULL DEFAULT '0',
  `cost_price` decimal(15,2) DEFAULT NULL,
  `sold_count` int NOT NULL DEFAULT '0',
  `status` enum('active','completed','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `normalized_batch_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_batches_product_id_status_index` (`product_id`,`status`),
  KEY `inventory_batches_normalized_batch_name_index` (`normalized_batch_name`),
  KEY `inventory_batches_created_at_index` (`created_at`),
  KEY `inv_batches_product_status_idx` (`product_id`,`status`),
  CONSTRAINT `inventory_batches_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_batches`
--

LOCK TABLES `inventory_batches` WRITE;
/*!40000 ALTER TABLE `inventory_batches` DISABLE KEYS */;
INSERT INTO `inventory_batches` VALUES ('019f8d51-beb7-70fe-8971-c548060f21eb','019f846e-6956-7325-8850-3c50fa1c6c3d','BM3 Trống 3 Slot - 23/7/2026 11:52',3,NULL,0,'active','2026-07-22 21:52:52','2026-07-22 22:18:26','bm3 trong 3 slot - 23/7/2026 11:52');
/*!40000 ALTER TABLE `inventory_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalized_secret_data` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` enum('available','sold','reserved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `order_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sold_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_items_order_id_foreign` (`order_id`),
  KEY `inventory_items_product_id_status_index` (`product_id`,`status`),
  KEY `inventory_items_batch_id_status_index` (`batch_id`,`status`),
  KEY `inventory_items_normalized_secret_data_index` (`normalized_secret_data`),
  CONSTRAINT `inventory_items_batch_id_foreign` FOREIGN KEY (`batch_id`) REFERENCES `inventory_batches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
INSERT INTO `inventory_items` VALUES ('019f8d52-6377-735b-a567-4c501f3ba641','019f8d51-beb7-70fe-8971-c548060f21eb','019f846e-6956-7325-8850-3c50fa1c6c3d','eyJpdiI6IjRNbDBWTXJ1WkMvbkRqNDUxVDZoS0E9PSIsInZhbHVlIjoiUVFlekR2cllsUnhiZGp1dDdMNlYvdz09IiwibWFjIjoiZjRkZWY3MjJmZDc1ZjcwYWQ1ZTUyMTVmM2RmODg0MmZjMDdmMzVkY2U5MjlkODMxYWNjZGRmMTY4NzRjMzMxMSIsInRhZyI6IiJ9','1','available',NULL,NULL,'2026-07-22 21:53:34','2026-07-22 21:53:34'),('019f8d69-2660-7001-a326-6c4cd1b7cf4d','019f8d51-beb7-70fe-8971-c548060f21eb','019f846e-6956-7325-8850-3c50fa1c6c3d','eyJpdiI6ImFqYkpocUEzL3B1aURkY0RiVXFUQ3c9PSIsInZhbHVlIjoiZjVOV0M2USs5SFF3U3BHZEJDb3UyUT09IiwibWFjIjoiYzA5MmRkYjI2MTdjOWM5ZTZmNTk5ZWRhZjIwZjk0OWVmNzNiOWUzYWZiYjI3YWUzYTZhZWIyMDRlYmY2OWZlMiIsInRhZyI6IiJ9','2','available',NULL,NULL,'2026-07-22 22:18:26','2026-07-22 22:18:26'),('019f8d69-2661-70f8-8d26-93383e050f26','019f8d51-beb7-70fe-8971-c548060f21eb','019f846e-6956-7325-8850-3c50fa1c6c3d','eyJpdiI6IkZ2QlhoRHFFUWR5NWhWS3A3eFJ6RkE9PSIsInZhbHVlIjoidmdGSm1jUXFLL1JMUytabmJJTExUZz09IiwibWFjIjoiNzUwNmY1MDBhNTY1NjYwZWRlODM5ZGVlNjhhYTk3YzEyYzhiZWQyMTBlMTI5NGYwZTcxZjBmZjRmZjE1YWU4OCIsInRhZyI6IiJ9','3','available',NULL,NULL,'2026-07-22 22:18:26','2026-07-22 22:18:26');
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_07_15_000000_create_categories_table',1),(5,'2026_07_15_000001_create_products_table',1),(6,'2026_07_15_000002_create_orders_table',1),(7,'2026_07_15_000003_create_order_items_table',1),(8,'2026_07_15_000004_create_inventory_batches_table',1),(9,'2026_07_16_031350_add_profile_fields_to_users_table',1),(10,'2026_07_17_114012_add_normalized_columns_to_tables',1),(11,'2026_07_17_225500_alter_products_category_id_foreign_restrict',1),(12,'2026_07_18_000001_add_soft_deletes_to_products_table',1),(13,'2026_07_18_015000_add_balance_to_users_table',1),(14,'2026_07_18_015100_create_deposits_table',1),(15,'2026_07_18_020000_add_performance_indexes_to_tables',1),(16,'2026_07_18_024541_create_system_settings_table',1),(17,'2026_07_18_100000_add_api_key_to_users_table',1),(18,'2026_07_18_184902_add_admin_wallet_address_to_deposits_table',1),(19,'2026_07_18_192800_add_status_to_users_table',1),(20,'2026_07_19_041702_add_username_to_users_table',1),(21,'2026_07_19_124806_add_binance_payment_fields_to_deposits_and_settings',1),(22,'2026_07_19_160908_remove_admin_binance_qr_from_system_settings',1),(23,'2026_07_20_000000_create_coupons_table',2),(24,'2026_07_20_000001_add_coupon_fields_to_orders_table',2),(25,'2026_07_20_010000_add_composite_performance_indexes',3),(26,'2026_07_21_000001_add_deposit_reconciliation_index',4),(27,'2026_07_21_100000_create_suppliers_and_add_source_fields',4),(28,'2026_07_21_200000_add_token_version_to_users_table',5),(29,'2026_07_21_200001_encrypt_sensitive_system_settings',5),(30,'2026_07_21_200002_add_api_key_hash_to_users_table',6),(31,'2026_07_21_062251_encrypt_existing_api_keys',7),(32,'2026_07_21_210000_add_catalog_driver_to_suppliers_table',8),(33,'2026_07_21_220000_backfill_user_api_key_hashes',9),(34,'2026_07_23_000000_add_uid_to_users_table',9),(35,'2026_07_23_000001_add_revoked_status_to_deposits_table',10),(36,'2026_07_23_000002_update_uid_to_numeric_in_users_table',11),(37,'2026_07_23_000003_create_inventory_items_table',12),(38,'2026_07_23_000004_drop_keys_pool_from_inventory_batches_table',13),(39,'2026_07_23_000005_add_cost_price_to_inventory_batches_and_order_items',14),(40,'2026_07_24_000000_create_user_sessions_table',15),(41,'2026_07_23_170000_add_products_enabled_to_suppliers_table',16),(42,'2026_07_24_090000_add_supplier_previous_status_to_products_table',17),(43,'2026_07_24_120000_add_stock_import_settings_and_price_precision',18),(44,'2026_07_24_150000_add_supplier_fulfillment_to_orders',19),(45,'2026_07_24_170000_increase_user_balance_precision',20),(46,'2026_07_24_130000_add_is_active_to_categories_table',21),(47,'2026_07_24_140000_create_warranty_policies_table',22),(48,'2026_07_24_140001_create_faqs_table',22);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(20,8) NOT NULL,
  `cost_price` decimal(20,8) DEFAULT NULL,
  `quantity` int NOT NULL,
  `supplier_quantity` int unsigned NOT NULL DEFAULT '0',
  `local_quantity` int unsigned NOT NULL DEFAULT '0',
  `supplier_order_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_keys` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_index` (`order_id`),
  KEY `order_items_product_id_index` (`product_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES ('019f8a13-c837-712c-b18e-972297972f64','019f8a13-c832-7244-ad03-10e2690cdf1d','019f82af-5c6b-7359-8aa5-7fd2c7eba814','BM3 Ngâm Full 3',1.52000000,1.52000000,1,0,0,NULL,NULL,'eyJpdiI6Ii9HdzV4OWRITWpFcTdzYkZjSERQM1E9PSIsInZhbHVlIjoicSt0UlhmRnJpVnFhWE15eGRXUnVJTUovN0VjUU44UUtQLzl2eEltZ2xRZ210Mk44YUhYUkk2bkdjdktSeVcydjdhbS9MSXh3bWRkOXpBZ0hLeEJBaEdKdFJqWFdoYUp1YkVPTUx0ZnlmOVoyR0tScis5WTdYSk5rWDRBTGZCbG00VS9BRmgrZWJZZmxJL2tDZVJmV3pqV0w2SHJOOHYzRDJuMER0Sml4WTQyejRxVklGd0hWeTBKVEkvNkxMSU81SWMyazNjRUtjVkNpK1dpUE9zU1cveXFjV0VFS1M1Nk9naTR4SVdSc2xUNEVZbXRhN3YvNTV0MFRSbmlyVXJnM3M1SjVVaTVyZHRKemN2U2lhamk4ZjczZmdhK083Rm4vUzl0bFUxRHdoK1k0dmtsZkpqb3cwRXd4SXE3U0NtTENLM2xwcmU1NGh5azZrcG9YZnE2UE9Gbk14NkxlSHZNckI0U05EWHIrQUpPMHMvbXdtWHpsMUFLUFliRi96WWVPY3hTNm1icU9SMUhId3IzK01TRnZwUmVyS1VoVEVUdW5XZzZGWGwxMlFsSjlIeDdRdVpvS09QMDROejlyMm0wYXZkTFJzK3R6QzFwa0dnY09STFk2bnQ3RmJ6cXo3V1E5SE0wRGI5OVd3QUZzb1Z6QVJ0TWxxMEpnT3ZSVmJsZy8iLCJtYWMiOiIzNTNiZTgyYzZmNDQ0ZTNiYTQ3YTcyZDAwNThmYzdkNTVkZWRkNWUwMGRlNzNiODQxOTUwNDI3MjhhNzFmZTk3IiwidGFnIjoiIn0=','2026-07-22 06:46:20','2026-07-22 20:39:51'),('019f8a15-c34f-714d-85a9-8f8e6ddfa3c9','019f8a15-c2c9-724b-8ced-153184feccdd','019f82af-5cb6-7256-ba25-d9a759529690','Via Ngoại Limit 50$ Có TKQC Cổ (No2FA)',4.94000000,4.94000000,1,0,0,NULL,NULL,'eyJpdiI6IkhpZUxyZWlEOGNVamRVS202OEMvT0E9PSIsInZhbHVlIjoiSWRUTVcxeGJ2blh6NSs1OXM2Zk9HV21FNTZ2R0kwZU5jb0pESDU0TElLaz0iLCJtYWMiOiJkYmY1OGU2OGYyMzEyYzA1YzNmYTBkZTc3OGU2ODBkMmI2Njc3MDk5ZDA2M2Q0ZDViZjZiNDI0MDQ0MGI0ZmE2IiwidGFnIjoiIn0=','2026-07-22 06:48:29','2026-07-22 20:39:51'),('019f8a16-548d-73b3-a1a2-a375fe7e943b','019f8a16-5489-713e-916c-fd8ff9776ef6','019f82af-5cb6-7256-ba25-d9a759529690','Via Ngoại Limit 50$ Có TKQC Cổ (No2FA)',4.94000000,4.94000000,1,0,0,NULL,NULL,'eyJpdiI6InYwK2xiMDlpQ2FJMEtSc3lpQzc2ckE9PSIsInZhbHVlIjoiR0prK2ptVkNrSUplcXVsWnZCSTBubFhsVWVyRmpEemJ0UVNZMW9Wb0VVbz0iLCJtYWMiOiJjMDk0NzY0YzE2ODI2NDBlNGQyZjA1ZWVjYmU5ODk0MDIzNDJmYmUyNGQ2ZGYyM2JiMzkxZWFjYjZiZDUzYjZhIiwidGFnIjoiIn0=','2026-07-22 06:49:07','2026-07-22 20:39:51'),('019f8a31-5d09-7109-ab8e-2411d457ea41','019f8a31-5d05-7245-b818-51505e0f8e4d','019f82af-5cc2-706e-9164-a9d62218db9f','Full Via Limit 200$',9.13000000,9.13000000,1,0,0,NULL,NULL,'eyJpdiI6ImV3ekxOcTJMY05KcWdWRy81Vm9SQ1E9PSIsInZhbHVlIjoiY0g5UXF0TWRubHB2aTlxaG11d3NNdz09IiwibWFjIjoiMmJiYTdjMWQ4MWE2ZGZhZjliNWI1NzZkOTMwMTNmNjI0OTM4NjAwNTc1MTcxMGJlYzk1NDViMzZkMTlmNjkxMiIsInRhZyI6IiJ9','2026-07-22 07:18:38','2026-07-22 20:39:51'),('019f8a90-db40-728d-9c37-d8dbe97e860a','019f8a90-db3c-73a7-bef1-92b948390d43','019f82af-5cc2-706e-9164-a9d62218db9f','Full Via Limit 200$',9.13000000,9.13000000,2,0,0,NULL,NULL,'eyJpdiI6IlNleHlibjJaQVRxaVhJZ2JJSjZOZ0E9PSIsInZhbHVlIjoidkRma0M1c0JtOUlLSzJkcHNpVUpGZz09IiwibWFjIjoiNjg5MWNmYmU4MWMyNWI5NjNlODJhZWZjYTFkMjVhYmJmY2RlNDkzNTYzNTEyMGE3Y2U3NDFlZjM0ZTM1NGU2ZCIsInRhZyI6IiJ9','2026-07-22 09:02:56','2026-07-22 20:39:51'),('019f8a9a-d9c5-738e-b3d1-d33aba1f98d3','019f8a9a-d9c1-719f-925e-0c59fbb8ddbc','019f82af-5cc2-706e-9164-a9d62218db9f','Full Via Limit 200$',9.13000000,9.13000000,1,0,0,NULL,NULL,'eyJpdiI6ImRYeVd3WEMrZmRBcmxFNkJYdGN2dFE9PSIsInZhbHVlIjoieXE5dUpBTlV0SHRyZ1lwODVtSFE0UT09IiwibWFjIjoiMGEzMmY0MmVmOTQwZTMyNjhlYTZjMjEyOTNkMzNmZDg4Yjc3YjBhZjcyOTU3MTcwYjA0ZTk5MThjZGM4NTNhZiIsInRhZyI6IiJ9','2026-07-22 09:13:51','2026-07-22 20:39:51'),('019f8ad1-6d60-7259-80bd-97965c4ac9e6','019f8ad1-6d5d-70fc-ab4c-1d27aae3a79b','019f82af-5cc2-706e-9164-a9d62218db9f','Full Via Limit 200$',9.13000000,9.13000000,1,0,0,NULL,NULL,'eyJpdiI6IitrNlBwSVRFc3ZHd2kzd2hzUEhYb0E9PSIsInZhbHVlIjoiL0MyS1JndEpkM0k5OE4rVWlDWmpHZz09IiwibWFjIjoiMmI1NzY2YzNjOGI4OWUxY2YxOTUyODdiMTA3NjRhZmFlNTQ4NGViZDFlZmQwZDdlZDQ3YmJmZTcyYzMwZDAxYyIsInRhZyI6IiJ9','2026-07-22 10:13:28','2026-07-22 20:39:51'),('019f8d0c-5042-73d8-aff0-1e73b6b6ed72','019f8d0c-503e-72c1-b37c-75a506949d49','019f82af-5cc2-706e-9164-a9d62218db9f','Full Via Limit 200$',9.13000000,9.13000000,3,0,0,NULL,NULL,'eyJpdiI6IlBHUzBmUk56NEVOWXQzaFdHNHZ0N0E9PSIsInZhbHVlIjoicFFiaklubjIrNHJyZVUwS3BTZDJkZk1XZnFVOFFPZW9IWWIvdEtXb2ticz0iLCJtYWMiOiJhMjM2ZjlkNDMyMjBhYWNhNjQ5ZTAxZGMxODdjNzA3MDRmMmZhMjI3NjA0NDI5ZjM2OWVjZGUwNDdjYzY5NGZiIiwidGFnIjoiIn0=','2026-07-22 20:37:02','2026-07-22 20:39:51'),('019f902c-01ed-7236-8669-19544cf54f9a','019f902c-01ec-715f-88d4-9c145fb6cb74','019f82af-5e5b-71f0-862c-8d15f88b57bb','Hotmail Trusted [GRAPH API]',0.01334855,0.01026772,1,1,0,'10887','ads7979','eyJpdiI6InJoVTVodlNFbFF4MTk4VDRHWjJmZXc9PSIsInZhbHVlIjoiOVc2S0NEb1FJL2gvREN3KzBGZVlpWmQyYkJ4OEpOWVNpZmNsbm9EcFdibEQwdDZOcThJL0oxQk1tZ2RScFZGKzNvS05pQWhLa3NjT2dVa2FVL0twMjZkTUluc3VBV09oTFN5T0ZacFI0NkNrUzVmQXFXd3V3RXZ0eC9pNVd1ZTBieDE3WWhsTFNtTm5USVVsSFpFSWpkTU0rcTVHaVpWeXFaaWgxMHQzK0Z3dk5BQkdoVjg2Ynd1OVpadWxRWi8rb25FMjNXRlVyUmsrYXdaQTBLZ1BFZ3djdlAyOVZ3azMweG9hQWVQY1V6dE9LS3JhdDhQN2tvYVBmWGZsVVRXSnNyYmxXelk5NHAzclNqVGVFOWtHS0xEby9VcXljVDBQdTZYcHlCeDZtV1BBOWdmVjJIMGhEb3hVQzkzY1dmVWQ3VlQvU0VPMFNQN3kxcnpCRmdhVndvTWZZQW1FMWd5R2ROc2UwN3QyK0swOW9MQzYwN050TnVGaTBXamlrVjlVdXQ2a2d3MDhvUExWUmtNZjJhVWM2MWNNMzQwQ2pNWG5pMTgrendtd1pTc0l3emZJYkJPU2VHcXIvRWMrN2Z6WkExckx6VHlTb0dNZzEwWDRjWWlMVDFneDdJL2JwMnJ6dUd0SkhJVDd6UVhPaDdqbmVUTUhBZHN2bSswZW1aNTdwaUpvbTZZWVYxV04vaUJlZzlmRDJrZ1kvbnhZUHJCVW90ZFBPeVRzdU9DaEVNVjVlbGNhcE5QOGxzZ2FITWhrdzB4QkF1aTVGL2xXeTlFdmZURG96eUVQN29uWEFUNXZMWjNxSmJSM2V2MFlXaysxVWVMb0oxcHhNVHFyYmlaYXJqckhubjRDYlgwZjFwUEhLMitoWkhtVmg2TVJCWUdSOGJRSEs3TTZCcW5sU2RzQjNlWkJVeGxITTZsajA0UklqdXhtR2p2MUVpeUN5dkdoOVV1am9SNkE0ZDlHREpxa2xLbmhTRGFwNEdxenhWMGhvN3FkT2wraEZyZGxYU2NCSGp1bHJRV3lsa3lpaGlacTBNL2xQQT09IiwibWFjIjoiN2YzOTNlOGE4ZWIwYTg2YzIxMGVmNjllMWVkYjU0NDg5MTg0ZDhjYjFiZGE0ZGU0ODQ4NzViOTMxMWY5MDU5MyIsInRhZyI6IiJ9','2026-07-23 18:10:31','2026-07-23 18:10:31'),('019f9049-276f-70f4-b3dd-cb47d4dbf0b3','019f9049-2760-735b-aa23-519943846b39','019f82af-5e5b-71f0-862c-8d15f88b57bb','Hotmail Trusted [GRAPH API]',0.01334804,0.01026772,1,1,0,'10892','ads7979','eyJpdiI6InFoNU41MjdJNUJIaCs2anVRdE8rM3c9PSIsInZhbHVlIjoiTVoyRnhuMmhWVitWdDBYRlozY2o2b1l4RnZEby9kMnppZDBBRzVlcGdBYW94QTduVHVjM21lNVZhckdVaWQ0dVFkOFFFb2dSUTJFUVpwb04wR09vR1dZT1QwVktNTzZjUXFHVVlmcll1Q2ZZenRDd3FnNDlWbHBJSndpZUxxWGFkNjJZYXJUOTlXVXdwRnNudFJGay9HK2oxQTJOZXBrNG1vRVVSRTRVYm9YZHpNb3l4eUpzd2IrZUtFOHNMc0xlYS94Ly9mY0h5c2RMZ2hBK0Ewb0hRbmtRV1JibXhrTnNkbFU0SkhjZGlZTVhJRGRMbmIrd2lyNG9ydy9VSzdBZWl4NHk1SVc5WWoyaHI0MWlpTUkxcGptOVlSaE13TXZjSGxiT1hkenVkUUhoMHpzWDJ4TEJZRHdXc2o1U2Q1Vmw3M3dHMDBWVC9pMmlMU3pKUUk0SlZzeHl6cmdYcHo5RUhwT3YrNXFKZTFidzBtS3dod01BM0NmSWg1Uy9xNTdBZktKNVphTmh3OXZFY3RnaFhjdmlyYmRxVmhENGpxMExIRW9FeHgvZGF1K0lWeDJRN3VkRVA4SVBDTjBzR29RQnB1K1l4Yzcra3EwYitVRHdaZTk4aUNXQzkyVkM0THpicUhjT0gvZTV4MGVubjQ0Q2pFakw2TFpTRkNWcFNYQzNmMU1VckV4ZkhtcXRCaG50cTFKek9tRmgvYTc0eFdFNDNxd1ZmR05DbXBBK0hFcWhhcUhBQlpjNmJYOWM4M3dlRTZIOWJQNnYvRTRkV0JJdjBZckZ6UUFPNitFRGNObzduNkVEdEJGSVJRRGQ3Q0hSWWFXM2xzWmRTeHhxQzFBM1V0Z1dKYWtjY1hoY1hmZjRvaXBMcTFtbHJPM1BYQUdrd0VSMW5Fem1Reit3Q2dLU3l2WGwvYUw0VVRuSDIxVS90NEJhZkM4S3I5ZUJwdlQzY0o3YllpNk0rOGxVa1JGMTRZYUhZdHRRMS9ZTHY4U3BqMlNoL2xoQVhYLzVzSkhhIiwibWFjIjoiMzI4NDJkYzZlMzEwN2RmMTI4NmM1NTE5MzliMjM1NTAxNWQ1NzllOGJlNDBiNWU5NTRiYmUwZDRiYzEwMzJmNCIsInRhZyI6IiJ9','2026-07-23 18:42:21','2026-07-23 18:42:21');
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotency_key` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` decimal(20,8) NOT NULL,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(20,8) NOT NULL DEFAULT '0.00000000',
  `coupon_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','paid','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_code_unique` (`order_code`),
  UNIQUE KEY `orders_user_id_idempotency_key_unique` (`user_id`,`idempotency_key`),
  KEY `orders_user_id_index` (`user_id`),
  KEY `orders_status_index` (`status`),
  KEY `orders_created_at_index` (`created_at`),
  KEY `orders_coupon_id_foreign` (`coupon_id`),
  KEY `orders_user_status_created_idx` (`user_id`,`status`,`created_at`),
  KEY `orders_status_created_idx` (`status`,`created_at`),
  CONSTRAINT `orders_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('019f8a13-c832-7244-ad03-10e2690cdf1d','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-AKY4FQ',NULL,1.52000000,NULL,0.00000000,NULL,'paid','2026-07-22 06:46:20','2026-07-22 06:46:20'),('019f8a15-c2c9-724b-8ced-153184feccdd','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-VLYKML',NULL,4.94000000,NULL,0.00000000,NULL,'paid','2026-07-22 06:48:29','2026-07-22 06:48:29'),('019f8a16-5489-713e-916c-fd8ff9776ef6','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-BA75K7',NULL,4.94000000,NULL,0.00000000,NULL,'paid','2026-07-22 06:49:07','2026-07-22 06:49:07'),('019f8a31-5d05-7245-b818-51505e0f8e4d','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-8SG1RN',NULL,9.13000000,NULL,0.00000000,NULL,'paid','2026-07-22 07:18:38','2026-07-22 07:18:38'),('019f8a90-db3c-73a7-bef1-92b948390d43','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-6PJNZC',NULL,18.26000000,NULL,0.00000000,NULL,'paid','2026-07-22 09:02:56','2026-07-22 09:02:56'),('019f8a9a-d9c1-719f-925e-0c59fbb8ddbc','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-AB7K8W',NULL,9.13000000,NULL,0.00000000,NULL,'paid','2026-07-22 09:13:51','2026-07-22 09:13:51'),('019f8ad1-6d5d-70fc-ab4c-1d27aae3a79b','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260722-9ZSTET',NULL,9.13000000,NULL,0.00000000,NULL,'paid','2026-07-22 10:13:28','2026-07-22 10:13:28'),('019f8d0c-503e-72c1-b37c-75a506949d49','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260723-VL1XPI',NULL,27.39000000,NULL,0.00000000,NULL,'paid','2026-07-22 20:37:02','2026-07-22 20:37:02'),('019f902c-01ec-715f-88d4-9c145fb6cb74','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260724-RX06NV','019f90ab-1234-7abc-8def-1234567890ab',0.01334855,NULL,0.00000000,NULL,'paid','2026-07-23 18:10:31','2026-07-23 18:10:31'),('019f9049-2760-735b-aa23-519943846b39','019f7d2f-cf44-723f-8c30-13b7ea78dadb','ORD-20260724-BPQKOW','d14fbcae-3429-46ba-9368-c761bb70b0fd',0.01334804,NULL,0.00000000,NULL,'paid','2026-07-23 18:42:21','2026-07-23 18:42:21');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(20,8) NOT NULL,
  `supplier_price_vnd` decimal(15,2) DEFAULT NULL,
  `supplier_stock` int unsigned DEFAULT NULL,
  `supplier_out_of_stock_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `supplier_synced_at` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `supplier_previous_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attributes` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `normalized_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  UNIQUE KEY `products_supplier_id_external_id_unique` (`supplier_id`,`external_id`),
  KEY `products_status_index` (`status`),
  KEY `products_price_index` (`price`),
  KEY `products_category_id_index` (`category_id`),
  KEY `products_normalized_name_index` (`normalized_name`),
  KEY `products_deleted_at_index` (`deleted_at`),
  KEY `products_created_at_index` (`created_at`),
  KEY `products_cat_status_created_idx` (`category_id`,`status`,`created_at`),
  KEY `products_status_created_idx` (`status`,`created_at`),
  KEY `products_supplier_id_status_index` (`supplier_id`,`status`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('019f82af-5c54-7394-99b8-16412f243f37','019f829a-f708-7093-890d-4950e6ce2e66','2','019f82af-5c43-710f-85e6-ff318e943418','BM50$ Ngâm','ads7979-2-bm50-ngam','Chưa tạo TKQC | Phù hợp kích tut BM3 | Created: 07/2026',1.11233648,22500.00,4770,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm50$ ngam',NULL),('019f82af-5c57-734c-915c-59b525cbcc1d','019f829a-f708-7093-890d-4950e6ce2e66','327','019f82af-5c43-710f-85e6-ff318e943418','BM50$ Có TK','ads7979-327-bm50-co-tk','Đã tạo TKQC | Created: 07/2026',0.88986918,18000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm50$ co tk',NULL),('019f82af-5c5c-7112-af75-b81299facf9b','019f829a-f708-7093-890d-4950e6ce2e66','3','019f82af-5c43-710f-85e6-ff318e943418','BM50$ Ngâm Kháng','ads7979-3-bm50-ngam-khang','Chưa tạo TKQC |Phù hợp cầm TKCN | Phù hợp kích tut BM3 | Created: 07/2026',1.11233648,22500.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm50$ ngam khang',NULL),('019f82af-5c62-71b1-90a5-7f62f0955065','019f829a-f708-7093-890d-4950e6ce2e66','469','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 Không Tạo Được Tài Khoản (Cầm Đối Tác, Dòng 2, Page)','ads7979-469-bm3-khong-tao-duoc-tai-khoan-cam-doi-tac-dong-2-page','Phù hợp dùng cầm TKCN dòng 2, đối tác, cầm Page | Created: Jul/2026',0.88986918,18000.00,1127,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm3 khong tao duoc tai khoan (cam doi tac, dong 2, page)',NULL),('019f82af-5c66-7166-abe4-1693699b16a6','019f829a-f708-7093-890d-4950e6ce2e66','5','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 Trống 3 Slot','ads7979-5-bm3-trong-3-slot','Chưa tạo TKQC | Limit tăng theo chi tiêu cực nhanh | Created:  Jun/2026',1.77973836,36000.00,541,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm3 trong 3 slot',NULL),('019f82af-5c6b-7359-8aa5-7fd2c7eba814','019f829a-f708-7093-890d-4950e6ce2e66','7','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 Ngâm Full 3','ads7979-7-bm3-ngam-full-3','Đã tạo 3 TKQC | Limit 50$ | Limit tăng theo chi tiêu cực nhanh | Created:  Jul/2026',1.77973836,36000.00,358,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm3 ngam full 3',NULL),('019f82af-5c6f-7185-8f4d-be9f0e7078f7','019f829a-f708-7093-890d-4950e6ce2e66','517','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 Ngâm Full 4','ads7979-517-bm3-ngam-full-4','Đã tạo 4 TKQC | Limit 50$ | Limit tăng theo chi tiêu cực nhanh | Created:  Jul/2026',2.22467295,45000.00,27,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm3 ngam full 4',NULL),('019f82af-5c72-7147-ada8-96348a726fd4','019f829a-f708-7093-890d-4950e6ce2e66','364','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 XÁC MINH DOANH NGHIỆP FULL 3','ads7979-364-bm3-xac-minh-doanh-nghiep-full-3','Đã tạo 3 TKQC | Limit 50$ | Limit tăng theo chi tiêu cực nhanh | Created: Jul/2026',8.89869182,180000.00,318,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm3 xac minh doanh nghiep full 3',NULL),('019f82af-5c75-71cc-8dfe-f14ec086fccc','019f829a-f708-7093-890d-4950e6ce2e66','1305','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 XÁC MINH DOANH NGHIỆP FULL 4','ads7979-1305-bm3-xac-minh-doanh-nghiep-full-4','Đã tạo 4 TKQC | Limit 50$ | Limit tăng theo chi tiêu cực nhanh | Created: Jul/2026',11.12336477,225000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','bm3 xac minh doanh nghiep full 4',NULL),('019f82af-5c7d-71d0-8482-57a7531c8eed','019f829a-f708-7093-890d-4950e6ce2e66','22','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Chat Support','ads7979-22-via-chat-support','Có thể Chat Support Facebook | Created: 2025 | Checkpoint Mail',5.33921509,108000.00,52,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via chat support',NULL),('019f82af-5c82-73a9-a87e-3d967539ea71','019f829a-f708-7093-890d-4950e6ce2e66','12','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Ngoại Cổ XMDT Die Ads','ads7979-12-via-ngoai-co-xmdt-die-ads','Green tick: 2 Lines | Tích ẩn | Ad account: Die | Created: 2008-2024',3.11454214,63000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co xmdt die ads',NULL),('019f82af-5c86-70bb-8b01-0250345fdec5','019f829a-f708-7093-890d-4950e6ce2e66','10','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Ngoại Cổ XMDT Limit 50$','ads7979-10-via-ngoai-co-xmdt-limit-50','Green tick: 2 Lines | Tích ẩn | Created: 2008-2024',5.33921509,108000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co xmdt limit 50$',NULL),('019f82af-5c8b-7386-adff-8fe3738153e0','019f829a-f708-7093-890d-4950e6ce2e66','11','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Philippines Cổ XMDT Limit 50$','ads7979-11-via-philippines-co-xmdt-limit-50','Green tick: 2 Lines | Tích ẩn | Created: 2008-2023',7.11895345,144000.00,160,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co xmdt limit 50$',NULL),('019f82af-5c91-720e-974d-447239c97c4f','019f829a-f708-7093-890d-4950e6ce2e66','13','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Colombia Cổ XMDT Limit 50$','ads7979-13-via-colombia-co-xmdt-limit-50','Green tick: 2 Lines | Tích ẩn | Created: 2008-2023',7.11895345,144000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co xmdt limit 50$',NULL),('019f82af-5c96-723a-b806-2b49b423e27a','019f829a-f708-7093-890d-4950e6ce2e66','14','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Indonesia Cổ Kháng 902 Die Ads','ads7979-14-via-indonesia-co-khang-902-die-ads','Green tick: 3 Lines | Tích ẩn | Ad account: Die | Created: 2008-2023',5.33921509,108000.00,48,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co khang 902 die ads',NULL),('019f82af-5c9c-73e1-9d0c-2a993b7b91cb','019f829a-f708-7093-890d-4950e6ce2e66','2430','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Indonesia Cổ Kháng 902 Live Ads','ads7979-2430-via-indonesia-co-khang-902-live-ads','Green tick: 3 Lines | Tích ẩn | Ad account: Live | Created: 2008-2022',8.00882263,162000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co khang 902 live ads',NULL),('019f82af-5ca1-7113-95f9-39b47b17e333','019f829a-f708-7093-890d-4950e6ce2e66','2692','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Colombia Cổ Kháng 902 Die Ads','ads7979-2692-via-colombia-co-khang-902-die-ads','Green tick: 3 Lines | Tích ẩn | Ad account: Die | Created: 2008-2022',5.33921509,108000.00,290,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co khang 902 die ads',NULL),('019f82af-5ca6-703d-95cd-31d64992d59e','019f829a-f708-7093-890d-4950e6ce2e66','2693','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Colombia Cổ Kháng 902 Live Ads','ads7979-2693-via-colombia-co-khang-902-live-ads','Green tick: 3 Lines | Tích ẩn | Ad account: Live | Created: 2008-2022',8.00882263,162000.00,66,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co khang 902 live ads',NULL),('019f82af-5caa-7206-99ae-945ddb81ab88','019f829a-f708-7093-890d-4950e6ce2e66','8','019f82af-5c77-72e6-bc4a-a959ae12bf0f','Via Ngoại Cổ Kháng 902 Die Ads','ads7979-8-via-ngoai-co-khang-902-die-ads','Green tick: 3 Lines | Tích ẩn | Ad account: Die | Created: 2008-2024',4.40485245,89100.00,118,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co khang 902 die ads',NULL),('019f82af-5cb2-73e5-83a4-719b1a67e72a','019f829a-f708-7093-890d-4950e6ce2e66','23','019f82af-5cad-7392-9656-9f8fa2545c95','Via Ngoại Limit 50$ Có TKQC Cổ','ads7979-23-via-ngoai-limit-50-co-tkqc-co','Bao đổi tiền, múi giờ, quốc gia | TKQC Cổ tạo từ: 2010–2024',6.67401886,135000.00,93,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai limit 50$ co tkqc co',NULL),('019f82af-5cb6-7256-ba25-d9a759529690','019f829a-f708-7093-890d-4950e6ce2e66','16','019f82af-5cad-7392-9656-9f8fa2545c95','Via Ngoại Limit 50$ Có TKQC Cổ (No2FA)','ads7979-16-via-ngoai-limit-50-co-tkqc-co-no2fa','Bao đổi tiền, múi giờ, quốc gia | TKQC Cổ tạo từ: 2010–2024 | Chưa dính IP Việt',5.78414968,117000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai limit 50$ co tkqc co (no2fa)',NULL),('019f82af-5cbb-725d-89e6-5dfcaeda4629','019f829a-f708-7093-890d-4950e6ce2e66','24','019f82af-5cad-7392-9656-9f8fa2545c95','Full Via Limit 50$ +7 USD đã paid mồi (No2FA)','ads7979-24-full-via-limit-50-7-usd-da-paid-moi-no2fa','TKQC đã camp mồi, paid mồi | Đã kháng 273 | Tiền tệ: +7 USD | Quốc gia US lách thuế',8.00882263,162000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','full via limit 50$ +7 usd da paid moi (no2fa)',NULL),('019f82af-5cc2-706e-9164-a9d62218db9f','019f829a-f708-7093-890d-4950e6ce2e66','2736','019f82af-5cbe-73f0-b751-0cadcb5c6b36','Full Via Limit 200$','ads7979-2736-full-via-limit-200','Bao đổi tiền, múi giờ, quốc gia | Không bao tụt Limit | TKQC Cổ tạo từ: 2010-2023',8.89869182,180000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','full via limit 200$',NULL),('019f82af-5cc7-70f4-846f-b3f9c979923d','019f829a-f708-7093-890d-4950e6ce2e66','802','019f82af-5cbe-73f0-b751-0cadcb5c6b36','Full Via Limit 250$','ads7979-802-full-via-limit-250','Bao đổi tiền, múi giờ, quốc gia | Bao tụt Limit | TKQC Cổ tạo từ: 2010-2023',26.69607545,540000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','full via limit 250$',NULL),('019f82af-5ccc-72dd-b16f-46d1e72701f8','019f829a-f708-7093-890d-4950e6ce2e66','804','019f82af-5cbe-73f0-b751-0cadcb5c6b36','Full Via Limit 350$','ads7979-804-full-via-limit-350','Bao đổi tiền, múi giờ, quốc gia | Không bao tụt Limit | TKQC Cổ tạo từ: 2010-2019',8.89869182,180000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','full via limit 350$',NULL),('019f82af-5cd4-70a0-993e-de9cb1a6547c','019f829a-f708-7093-890d-4950e6ce2e66','29','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Ngoại New (No2FA)','ads7979-29-via-ngoai-new-no2fa','Friend: 0-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025',0.66740189,13500.00,79,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai new (no2fa)',NULL),('019f82af-5cd8-70a7-af11-7b91279a97a1','019f829a-f708-7093-890d-4950e6ce2e66','20','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Ngoại Cổ 0-29 Friend (No2FA)','ads7979-20-via-ngoai-co-0-29-friend-no2fa','Friend: 0-29 | LIVE ADS  | Checkpoint Mail | Created: 2008-2024',1.11233648,22500.00,77,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co 0-29 friend (no2fa)',NULL),('019f82af-5cdd-7052-82f8-83fd71a36b1c','019f829a-f708-7093-890d-4950e6ce2e66','19','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Ngoại Cổ (No2FA)','ads7979-19-via-ngoai-co-no2fa','Friend: 30-1000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023',1.55727107,31500.00,201,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co (no2fa)',NULL),('019f82af-5ce2-7270-93c2-8098e0cb3adb','019f829a-f708-7093-890d-4950e6ce2e66','30','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Ngoại Cổ 500-3K Friend (No2FA)','ads7979-30-via-ngoai-co-500-3k-friend-no2fa','Friend: 500-3000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2024',3.33700943,67500.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co 500-3k friend (no2fa)',NULL),('019f82af-5ce6-704d-bd85-1b9f6b5e1828','019f829a-f708-7093-890d-4950e6ce2e66','31','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Ngoại Cổ 3-5K Friend (No2FA)','ads7979-31-via-ngoai-co-3-5k-friend-no2fa','Friend: 3000-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2024',4.44934591,90000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co 3-5k friend (no2fa)',NULL),('019f82af-5cea-7082-a30e-2b18b0309da2','019f829a-f708-7093-890d-4950e6ce2e66','32','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via India New (No2FA)','ads7979-32-via-india-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,52,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via india new (no2fa)',NULL),('019f82af-5cef-7231-8530-a13b1371d7e9','019f829a-f708-7093-890d-4950e6ce2e66','34','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Pakistan New (No2FA)','ads7979-34-via-pakistan-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via pakistan new (no2fa)',NULL),('019f82af-5cf4-72dc-ae2c-41bc3f75e32a','019f829a-f708-7093-890d-4950e6ce2e66','35','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Bangladesh New (No2FA)','ads7979-35-via-bangladesh-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,512,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via bangladesh new (no2fa)',NULL),('019f82af-5cf8-73e9-bdcc-b5ff17f8bc43','019f829a-f708-7093-890d-4950e6ce2e66','36','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Indonesia New (No2FA)','ads7979-36-via-indonesia-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,69,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia new (no2fa)',NULL),('019f82af-5cfc-71dc-bbbb-6289ad370468','019f829a-f708-7093-890d-4950e6ce2e66','37','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Indonesia Cổ (No2FA)','ads7979-37-via-indonesia-co-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',2.66960754,54000.00,228,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co (no2fa)',NULL),('019f82af-5d01-7155-9316-ebb015f6d704','019f829a-f708-7093-890d-4950e6ce2e66','5527','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Indonesia Cổ 500-3K Friend (No2FA)','ads7979-5527-via-indonesia-co-500-3k-friend-no2fa','Friend: 500-3000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',4.00441132,81000.00,13,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co 500-3k friend (no2fa)',NULL),('019f82af-5d06-7042-ae43-935e05d708f0','019f829a-f708-7093-890d-4950e6ce2e66','5528','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Indonesia Cổ 3-5K Friend (No2FA)','ads7979-5528-via-indonesia-co-3-5k-friend-no2fa','Friend: 3000-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',5.78414968,117000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co 3-5k friend (no2fa)',NULL),('019f82af-5d0c-7052-88d8-f482bf3dabe2','019f829a-f708-7093-890d-4950e6ce2e66','38','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Philippines New (No2FA)','ads7979-38-via-philippines-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines new (no2fa)',NULL),('019f82af-5d11-73b5-b368-e78e1eb6af9d','019f829a-f708-7093-890d-4950e6ce2e66','39','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Philippines Cổ (No2FA)','ads7979-39-via-philippines-co-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',2.66960754,54000.00,1092,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co (no2fa)',NULL),('019f82af-5d15-7086-88fe-2e4fbed58871','019f829a-f708-7093-890d-4950e6ce2e66','782','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Philippines Cổ 500-3K Friend (No2FA)','ads7979-782-via-philippines-co-500-3k-friend-no2fa','Friend: 500-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',4.00441132,81000.00,84,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co 500-3k friend (no2fa)',NULL),('019f82af-5d19-72c8-a71e-11b3a65761fc','019f829a-f708-7093-890d-4950e6ce2e66','783','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Philippines Cổ 3-5K Friend (No2FA)','ads7979-783-via-philippines-co-3-5k-friend-no2fa','Friend: 3000-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',5.78414968,117000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co 3-5k friend (no2fa)',NULL),('019f82af-5d1d-729d-9fb9-318d70629bf7','019f829a-f708-7093-890d-4950e6ce2e66','21','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Saudi Arabia New (No2FA)','ads7979-21-via-saudi-arabia-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via saudi arabia new (no2fa)',NULL),('019f82af-5d21-713a-b47a-79f83f877aa2','019f829a-f708-7093-890d-4950e6ce2e66','40','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Algeria New (No2FA)','ads7979-40-via-algeria-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via algeria new (no2fa)',NULL),('019f82af-5d28-705c-aca7-43dcbd6fcd3d','019f829a-f708-7093-890d-4950e6ce2e66','41','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Congo New (No2FA)','ads7979-41-via-congo-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,100,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via congo new (no2fa)',NULL),('019f82af-5d2f-73e7-aaa7-c4a0acee2218','019f829a-f708-7093-890d-4950e6ce2e66','102','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Nigeria New (No2FA)','ads7979-102-via-nigeria-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via nigeria new (no2fa)',NULL),('019f82af-5d34-732f-8bc8-db41a916c876','019f829a-f708-7093-890d-4950e6ce2e66','103','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Nigeria Cổ (No2FA)','ads7979-103-via-nigeria-co-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',2.66960754,54000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via nigeria co (no2fa)',NULL),('019f82af-5d3a-7255-a696-c088bc08e046','019f829a-f708-7093-890d-4950e6ce2e66','42','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Angola New (No2FA)','ads7979-42-via-angola-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via angola new (no2fa)',NULL),('019f82af-5d40-73e2-833b-2afcc0819372','019f829a-f708-7093-890d-4950e6ce2e66','43','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Egypt New (No2FA)','ads7979-43-via-egypt-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,62,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via egypt new (no2fa)',NULL),('019f82af-5d44-737a-8f0a-6fafa0b745ba','019f829a-f708-7093-890d-4950e6ce2e66','44','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Egypt Cổ (No2FA)','ads7979-44-via-egypt-co-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',2.66960754,54000.00,1,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via egypt co (no2fa)',NULL),('019f82af-5d49-72ce-a3f3-d95431bac142','019f829a-f708-7093-890d-4950e6ce2e66','45','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Madagascar New (No2FA)','ads7979-45-via-madagascar-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via madagascar new (no2fa)',NULL),('019f82af-5d4e-70e8-8fe0-3f94733c7161','019f829a-f708-7093-890d-4950e6ce2e66','55','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Timor Leste New (No2FA)','ads7979-55-via-timor-leste-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.22467295,45000.00,4,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via timor leste new (no2fa)',NULL),('019f82af-5d53-7379-bdaa-71337702a10b','019f829a-f708-7093-890d-4950e6ce2e66','46','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Brazil New (No2FA)','ads7979-46-via-brazil-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',3.55947673,72000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via brazil new (no2fa)',NULL),('019f82af-5d57-7241-8ab9-44fa4ac719c5','019f829a-f708-7093-890d-4950e6ce2e66','47','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Brazil Cổ (No2FA)','ads7979-47-via-brazil-co-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2023 | Chưa dính IP Việt',5.33921509,108000.00,59,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via brazil co (no2fa)',NULL),('019f82af-5d5c-7011-8bec-6fbcb93e0188','019f829a-f708-7093-890d-4950e6ce2e66','48','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Peru New (No2FA)','ads7979-48-via-peru-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',3.11454214,63000.00,111,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via peru new (no2fa)',NULL),('019f82af-5d60-733a-9093-08d38acf0477','019f829a-f708-7093-890d-4950e6ce2e66','49','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Venezuela New (No2FA)','ads7979-49-via-venezuela-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.66960754,54000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via venezuela new (no2fa)',NULL),('019f82af-5d65-7181-957f-03ce4597aaf7','019f829a-f708-7093-890d-4950e6ce2e66','52','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Ecuador New (No2FA)','ads7979-52-via-ecuador-new-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2024-2025 | Chưa dính IP Việt',2.66960754,54000.00,3,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ecuador new (no2fa)',NULL),('019f82af-5d69-72d6-b3f3-b17c618ae475','019f829a-f708-7093-890d-4950e6ce2e66','54','019f82af-5ccf-71a8-8bc3-1ee1121bd7ed','Via Colombia Cổ (No2FA)','ads7979-54-via-colombia-co-no2fa','Friend: 30-5000 | LIVE ADS  | Checkpoint Mail | Created: 2008-2022 | Chưa dính IP Việt',2.66960754,54000.00,2574,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co (no2fa)',NULL),('019f82af-5d70-72ab-b736-a1f40fad8ce2','019f829a-f708-7093-890d-4950e6ce2e66','15','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Ngoại New','ads7979-15-via-ngoai-new','Friend: 30-1000 | LIVE ADS | Created: 2025-2026 | Chưa dính IP Việt | Checkpoint Mail',1.11233648,22500.00,3863,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai new',NULL),('019f82af-5d74-73c8-9feb-49ea1222bd5f','019f829a-f708-7093-890d-4950e6ce2e66','56','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Ngoại Cổ','ads7979-56-via-ngoai-co','Friend: 30-5000 | LIVE ADS  | Created: 2008-2024 | Chưa dính IP Việt',2.66960754,54000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co',NULL),('019f82af-5d78-72cd-a7df-cf15e142d6a8','019f829a-f708-7093-890d-4950e6ce2e66','58','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Ngoại Cổ 3-5K Friend','ads7979-58-via-ngoai-co-3-5k-friend','Friend: 3000-5000 | LIVE ADS  | Created: 2008-2024 | Chưa dính IP Việt',7.11895345,144000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co 3-5k friend',NULL),('019f82af-5d7c-7131-a05b-8328f587d607','019f829a-f708-7093-890d-4950e6ce2e66','61','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Nepal New','ads7979-61-via-nepal-new','Friend: 30-5000 | LIVE ADS | Created: 2024-2025 | Chưa dính IP Việt',3.11454214,63000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via nepal new',NULL),('019f82af-5d7f-7126-8818-bb4257798bb2','019f829a-f708-7093-890d-4950e6ce2e66','62','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Nepal Cổ','ads7979-62-via-nepal-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2024 | Chưa dính IP Việt',4.00441132,81000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via nepal co',NULL),('019f82af-5d83-72fb-a7f4-db241031fd80','019f829a-f708-7093-890d-4950e6ce2e66','101','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Egypt Cổ','ads7979-101-via-egypt-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2024 | Chưa dính IP Việt',3.55947673,72000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via egypt co',NULL),('019f82af-5d88-703a-8b22-95efd185b5fd','019f829a-f708-7093-890d-4950e6ce2e66','63','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Philippines Cổ','ads7979-63-via-philippines-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',4.44934591,90000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co',NULL),('019f82af-5d90-70cc-9bd6-4e325ae612dd','019f829a-f708-7093-890d-4950e6ce2e66','64','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Philippines Cổ 500-3K Friend','ads7979-64-via-philippines-co-500-3k-friend','Friend: 500-3000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',6.67401886,135000.00,406,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co 500-3k friend',NULL),('019f82af-5d95-7023-916b-bd050bd4625d','019f829a-f708-7093-890d-4950e6ce2e66','65','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Philippines Cổ 3K-5K Friend','ads7979-65-via-philippines-co-3k-5k-friend','Friend: 3000-5000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',8.45375723,171000.00,84,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via philippines co 3k-5k friend',NULL),('019f82af-5d9a-71ee-a68c-f2ad40c83012','019f829a-f708-7093-890d-4950e6ce2e66','66','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Indonesia Cổ','ads7979-66-via-indonesia-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',4.44934591,90000.00,1738,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co',NULL),('019f82af-5d9e-73bf-938f-4609339c5890','019f829a-f708-7093-890d-4950e6ce2e66','67','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Indonesia Cổ 500-3K Friend','ads7979-67-via-indonesia-co-500-3k-friend','Friend: 500-3000 | LIVE ADS | Created: 2008-2022 | Chưa dính IP Việt',6.67401886,135000.00,642,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co 500-3k friend',NULL),('019f82af-5da2-70ef-8814-b29d95655644','019f829a-f708-7093-890d-4950e6ce2e66','68','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Indonesia Cổ 3-5K Friend','ads7979-68-via-indonesia-co-3-5k-friend','Friend: 3000-5000 | LIVE ADS | Created: 2008-2022 | Chưa dính IP Việt',8.45375723,171000.00,55,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via indonesia co 3-5k friend',NULL),('019f82af-5da6-7171-8c85-75baab2f8866','019f829a-f708-7093-890d-4950e6ce2e66','69','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Thailand Cổ','ads7979-69-via-thailand-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2022 | Chưa dính IP Việt',6.67401886,135000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via thailand co',NULL),('019f82af-5daa-71d7-a170-54d65f9b8647','019f829a-f708-7093-890d-4950e6ce2e66','2735','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Peru Cổ','ads7979-2735-via-peru-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2022 | Chưa dính IP Việt',4.44934591,90000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via peru co',NULL),('019f82af-5dad-72ad-8d90-d800a31d2983','019f829a-f708-7093-890d-4950e6ce2e66','70','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Colombia Cổ','ads7979-70-via-colombia-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',4.44934591,90000.00,3,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co',NULL),('019f82af-5db1-7375-a95f-b6f99b878aec','019f829a-f708-7093-890d-4950e6ce2e66','2690','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Colombia Cổ 500-3K Friend','ads7979-2690-via-colombia-co-500-3k-friend','Friend: 500-3000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',6.67401886,135000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co 500-3k friend',NULL),('019f82af-5db4-7233-9a47-d31623d6c113','019f829a-f708-7093-890d-4950e6ce2e66','2691','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Colombia Cổ 3-5K Friend','ads7979-2691-via-colombia-co-3-5k-friend','Friend: 3000-5000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',8.45375723,171000.00,1,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via colombia co 3-5k friend',NULL),('019f82af-5db9-706d-bb65-81714314d1c0','019f829a-f708-7093-890d-4950e6ce2e66','71','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Brazil Cổ','ads7979-71-via-brazil-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2023 | Chưa dính IP Việt',6.67401886,135000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via brazil co',NULL),('019f82af-5dbc-7296-b6d0-cf05288ffd5c','019f829a-f708-7093-890d-4950e6ce2e66','72','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Germany Cổ','ads7979-72-via-germany-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via germany co',NULL),('019f82af-5dc0-7367-a2eb-d8612edba60a','019f829a-f708-7093-890d-4950e6ce2e66','6732','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Spain Cổ','ads7979-6732-via-spain-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via spain co',NULL),('019f82af-5dc4-7077-b495-20d2288bc187','019f829a-f708-7093-890d-4950e6ce2e66','3104','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Bulgari Cổ','ads7979-3104-via-bulgari-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via bulgari co',NULL),('019f82af-5dc9-71dd-99e6-c6d9983c92eb','019f829a-f708-7093-890d-4950e6ce2e66','3103','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Switzerland Cổ','ads7979-3103-via-switzerland-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via switzerland co',NULL),('019f82af-5dcd-73cf-b259-dc5227183384','019f829a-f708-7093-890d-4950e6ce2e66','792','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Poland Cổ','ads7979-792-via-poland-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,201,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via poland co',NULL),('019f82af-5dd0-7092-a7ee-2eb384b8cf10','019f829a-f708-7093-890d-4950e6ce2e66','6730','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Turkey Cổ','ads7979-6730-via-turkey-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via turkey co',NULL),('019f82af-5dd3-71a2-88c5-e8970244bcb1','019f829a-f708-7093-890d-4950e6ce2e66','73','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Slovakia','ads7979-73-via-slovakia','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,542,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via slovakia',NULL),('019f82af-5dd7-7148-b6ac-17397f7ee476','019f829a-f708-7093-890d-4950e6ce2e66','74','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Czech Republic Cổ','ads7979-74-via-czech-republic-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,41,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via czech republic co',NULL),('019f82af-5ddc-70ef-8089-316fa5672286','019f829a-f708-7093-890d-4950e6ce2e66','796','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Hungary Cổ','ads7979-796-via-hungary-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via hungary co',NULL),('019f82af-5de0-701b-91b9-61296e5417ca','019f829a-f708-7093-890d-4950e6ce2e66','100','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via Austria Cổ','ads7979-100-via-austria-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',7.07445999,143100.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via austria co',NULL),('019f82af-5de3-71f4-bb54-b322495dbbb6','019f829a-f708-7093-890d-4950e6ce2e66','805','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via United Kingdom Cổ','ads7979-805-via-united-kingdom-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',8.89869182,180000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via united kingdom co',NULL),('019f82af-5de7-704c-adba-7e1e4bdaf6c0','019f829a-f708-7093-890d-4950e6ce2e66','75','019f82af-5d6c-71c4-a32c-db49989a6cc3','Via United States Cổ','ads7979-75-via-united-states-co','Friend: 30-5000 | LIVE ADS | Created: 2008-2021 | Chưa dính IP Việt',13.34803772,270000.00,54,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via united states co',NULL),('019f82af-5ded-70dc-be58-ad0b46ae9215','019f829a-f708-7093-890d-4950e6ce2e66','76','019f82af-5dea-7360-936b-3aa19da2dd52','Via Ngoại New DIE ADS (No2FA)','ads7979-76-via-ngoai-new-die-ads-no2fa','Thích hợp Seeding | DIE ADS | Friend : 0-5000 | Checkpoint Mail | Created: 2024-2025',0.66740189,13500.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai new die ads (no2fa)',NULL),('019f82af-5df2-704a-b7f7-3aad8b96f86f','019f829a-f708-7093-890d-4950e6ce2e66','18','019f82af-5dea-7360-936b-3aa19da2dd52','Via Ngoại New Die Ads','ads7979-18-via-ngoai-new-die-ads','Thích hợp Seeding | DIE ADS | Friend : 30-5000 | Checkpoint Mail | Created: 2024-2025',0.88986918,18000.00,701,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai new die ads',NULL),('019f82af-5df7-736f-8780-9e184051748e','019f829a-f708-7093-890d-4950e6ce2e66','9','019f82af-5dea-7360-936b-3aa19da2dd52','Via Ngoại Cổ DIE ADS (No2FA)','ads7979-9-via-ngoai-co-die-ads-no2fa','Thích hợp Seeding | DIE ADS | Friend : 0-5000 | Checkpoint Mail | Created: 2008-2024',1.11233648,22500.00,73,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co die ads (no2fa)',NULL),('019f82af-5dfc-7036-9461-b72ccea41a89','019f829a-f708-7093-890d-4950e6ce2e66','17','019f82af-5dea-7360-936b-3aa19da2dd52','Via Ngoại Cổ DIE ADS','ads7979-17-via-ngoai-co-die-ads','Thích hợp Seeding | DIE ADS | Friend : 30-1000 | Created: 2008-2024',2.22467295,45000.00,631,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co die ads',NULL),('019f82af-5e01-7368-a7dc-83242bcb38ca','019f829a-f708-7093-890d-4950e6ce2e66','77','019f82af-5dea-7360-936b-3aa19da2dd52','Via Ngoại Cổ DIE ADS 1-3K Friend','ads7979-77-via-ngoai-co-die-ads-1-3k-friend','Thích hợp Seeding | DIE ADS | Friend : 1000-3000 | Năm tạo: 2008-2024',4.44934591,90000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co die ads 1-3k friend',NULL),('019f82af-5e06-7138-b289-5d0de5719ccb','019f829a-f708-7093-890d-4950e6ce2e66','78','019f82af-5dea-7360-936b-3aa19da2dd52','Via Ngoại Cổ DIE ADS 3-5K Friend','ads7979-78-via-ngoai-co-die-ads-3-5k-friend','Thích hợp Seeding | DIE ADS | Friend : 3000-5000 | Năm tạo: 2008-2024',5.78414968,117000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via ngoai co die ads 3-5k friend',NULL),('019f82af-5e0c-7056-bb52-6b9ad2be5dbe','019f829a-f708-7093-890d-4950e6ce2e66','578','019f82af-5dea-7360-936b-3aa19da2dd52','Via United States Cổ DIE ADS','ads7979-578-via-united-states-co-die-ads','Thích hợp Seeding, Spy | DIE ADS | Friend : 30-5000 | Created: 2010-2021',8.85419836,179100.00,124,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','via united states co die ads',NULL),('019f82af-5e13-7061-a3ea-c27dc30f8c62','019f829a-f708-7093-890d-4950e6ce2e66','79','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Ngoại Random','ads7979-79-clone-ngoai-random','Có Avatar + Cover + Info | Created: > 2 day | Created Ads: > 2 day | Verify Hotmail | Đã bật 2FA',0.22246730,4500.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone ngoai random',NULL),('019f82af-5e18-736d-8ccd-b6bd13aba48f','019f829a-f708-7093-890d-4950e6ce2e66','80','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Ngoại Random Die Ads','ads7979-80-clone-ngoai-random-die-ads','Có Avatar + Cover + Info | Created: > 3 month | Very Hotmail | Đã Bật 2FA',0.06674019,1350.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone ngoai random die ads',NULL),('019f82af-5e1d-708e-ad4c-8ccc8681fa4e','019f829a-f708-7093-890d-4950e6ce2e66','81','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Ngoại Random 1-30 Friend','ads7979-81-clone-ngoai-random-1-30-friend','Có Avatar + Cover + Info | Created: > 1 month | Very Hotmail | Đã Bật 2FA | Friend: 1-30',0.26696075,5400.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone ngoai random 1-30 friend',NULL),('019f82af-5e22-7062-ae8e-7cb64f67e698','019f829a-f708-7093-890d-4950e6ce2e66','82','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Thailand','ads7979-82-clone-thailand','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone thailand',NULL),('019f82af-5e27-73c6-9e74-5d19f918bae9','019f829a-f708-7093-890d-4950e6ce2e66','83','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Hongkong','ads7979-83-clone-hongkong','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone hongkong',NULL),('019f82af-5e2b-7297-a295-4043c5de8013','019f829a-f708-7093-890d-4950e6ce2e66','84','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Singapore','ads7979-84-clone-singapore','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone singapore',NULL),('019f82af-5e30-73cf-97c8-c379a04ee167','019f829a-f708-7093-890d-4950e6ce2e66','85','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Taiwan','ads7979-85-clone-taiwan','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:38','clone taiwan',NULL),('019f82af-5e35-72e2-8aa7-911e88cdc393','019f829a-f708-7093-890d-4950e6ce2e66','86','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Ukraine','ads7979-86-clone-ukraine','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone ukraine',NULL),('019f82af-5e39-70a3-9115-fabfca9ded3f','019f829a-f708-7093-890d-4950e6ce2e66','87','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Germany','ads7979-87-clone-germany','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone germany',NULL),('019f82af-5e3d-7397-87d2-50d59da8dd69','019f829a-f708-7093-890d-4950e6ce2e66','88','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone France','ads7979-88-clone-france','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone france',NULL),('019f82af-5e40-71f1-b7ee-ed68bce180e7','019f829a-f708-7093-890d-4950e6ce2e66','89','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Canada','ads7979-89-clone-canada','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone canada',NULL),('019f82af-5e43-7167-b716-768b2b521324','019f829a-f708-7093-890d-4950e6ce2e66','90','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone Australia','ads7979-90-clone-australia','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone australia',NULL),('019f82af-5e47-7338-bdcc-c0cd6ca11e9b','019f829a-f708-7093-890d-4950e6ce2e66','2688','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone United Kingdom','ads7979-2688-clone-united-kingdom','Có Avatar + Cover + Info | Created: > 2 month | Created Ads: > 2 month | Verify Hotmail | Đã bật 2FA',0.35594767,7200.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone united kingdom',NULL),('019f82af-5e4a-7007-9f1c-6f2f968befd9','019f829a-f708-7093-890d-4950e6ce2e66','91','019f82af-5e0e-729a-a8e2-59ef4d9e2997','Clone United States','ads7979-91-clone-united-states','Có Avatar + Cover + Info | Created: > 5 day | Created Ads: > 5 day | Verify Hotmail | Đã bật 2FA',0.26696075,5400.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone united states',NULL),('019f82af-5e50-73e3-bcad-d1a749cc715b','019f829a-f708-7093-890d-4950e6ce2e66','92','019f82af-5e4d-730c-994f-86a322e0e883','Clone Việt Nam Verify Gmail (No2FA)','ads7979-92-clone-viet-nam-verify-gmail-no2fa','Có Avatar + Cover + Info | Ngày tạo: > 2 month | Chưa bật 2FA | Very Gmail | Friend: 0-20',0.22246730,4500.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone viet nam verify gmail (no2fa)',NULL),('019f82af-5e54-7312-abf9-cb982d5fa23f','019f829a-f708-7093-890d-4950e6ce2e66','93','019f82af-5e4d-730c-994f-86a322e0e883','Clone Việt Nam Verify Hotmail','ads7979-93-clone-viet-nam-verify-hotmail','Có Avatar + Cover + Info | Ngày tạo: > 3 month | Đã bật 2FA | Very Hotmail',0.26696075,5400.00,2256,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone viet nam verify hotmail',NULL),('019f82af-5e5b-71f0-862c-8d15f88b57bb','019f829a-f708-7093-890d-4950e6ce2e66','94','019f82af-5e56-7144-8a42-34ec76467805','Hotmail Trusted [GRAPH API]','ads7979-94-hotmail-trusted-graph-api','Live for 6-12 months | Không cần very SĐT | Recommend to use Graph API for access',0.01334804,270.00,6905,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:42:21','hotmail trusted [graph api]',NULL),('019f82af-5e5f-713e-b6b1-4ab72a40a0a1','019f829a-f708-7093-890d-4950e6ce2e66','95','019f82af-5e56-7144-8a42-34ec76467805','Outlook Trusted [GRAPH API]','ads7979-95-outlook-trusted-graph-api','Live for 6-12 months | Không cần very SĐT | Recommend to use Graph API for access',0.01334804,270.00,5871,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','outlook trusted [graph api]',NULL),('019f82af-5e64-70cd-a368-e0d623110e87','019f829a-f708-7093-890d-4950e6ce2e66','8326','019f82af-5e56-7144-8a42-34ec76467805','Hotmail Live Vĩnh Viễn','ads7979-8326-hotmail-live-vinh-vien','Live vĩnh viễn | Đã thêm mail khôi phục Fviainboxes | Recommend to use Graph API for access',0.04449346,900.00,5391,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','hotmail live vinh vien',NULL),('019f82af-5e6c-7202-932e-f9f1747f0cfa','019f829a-f708-7093-890d-4950e6ce2e66','96','019f82af-5e67-7153-9ee1-9c332fc1fd73','Clone Instagram US','ads7979-96-clone-instagram-us','Reg Android | Verify Phone | Đã Bật 2FA | Name US | Created: > 15 day',0.06674019,1350.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone instagram us',NULL),('019f82af-5e71-7287-94df-018124a1d274','019f829a-f708-7093-890d-4950e6ce2e66','97','019f82af-5e67-7153-9ee1-9c332fc1fd73','Clone Instagram US đã qua reg BM','ads7979-97-clone-instagram-us-da-qua-reg-bm','Reg Android | Verify Phone | Đã Bật 2FA | Name US | Created: > 2 month | Phù hợp spam, fishing...',0.03559477,720.00,0,0,'2026-07-23 18:41:39','active',NULL,'[]','2026-07-20 20:19:18','2026-07-23 18:41:39','clone instagram us da qua reg bm',NULL),('019f846e-694e-72b3-843a-b5bf840b3e1a','019f846e-66a7-7247-bb63-b9ebcf11be46','28009','019f846e-67ec-730a-a840-1921ffd184ea','BM50$ Ngâm','vlclone-28009-bm50-ngam','Chưa tạo TKQC | Phù hợp cầm TKCN | Phù hợp kích tut BM3 - BM10 | Created: 06/2026',1.13000000,25000.00,4850,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm50$ ngam',NULL),('019f846e-6954-700f-a6be-2f47c365b178','019f846e-66a7-7247-bb63-b9ebcf11be46','251365','019f846e-6950-7188-871e-a42e435bdd7a','BM3 Không Tạo Được Tài Khoản (Cầm Đối Tác, Dòng 2, Page)','vlclone-251365-bm3-khong-tao-duoc-tai-khoan-cam-doi-tac-dong-2-page','Phù hợp dùng cầm TKCN dòng 2, đối tác, cầm Page | Created:  Jun/2026',0.91000000,20000.00,1150,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 khong tao duoc tai khoan (cam doi tac, dong 2, page)',NULL),('019f846e-6956-7325-8850-3c50fa1c6c3d','019f846e-66a7-7247-bb63-b9ebcf11be46','251366','019f846e-6950-7188-871e-a42e435bdd7a','BM3 Trống 3 Slot','vlclone-251366-bm3-trong-3-slot','Chưa tạo TKQC | Trống 3 slot | Bao add thẻ nhảy limit cao | Bao nhét và chi tiêu phá limit siêu nhanh | Created:  Jun/2026',1.81000000,40000.00,590,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 trong 3 slot',NULL),('019f846e-6957-701e-af7f-ff44c339f6a0','019f846e-66a7-7247-bb63-b9ebcf11be46','251367','019f846e-6950-7188-871e-a42e435bdd7a','BM3 Trống 2 Slot','vlclone-251367-bm3-trong-2-slot','Đã tạo 1 TKQC | Trống 2 slot | Bao add thẻ nhảy limit cao | Bao nhét và chi tiêu phá limit siêu nhanh | Created:  Jun/2026',0.91000000,20000.00,0,0,'2026-07-22 07:08:50','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 trong 2 slot',NULL),('019f846e-6959-735b-97b3-597fd7db0d6f','019f846e-66a7-7247-bb63-b9ebcf11be46','251368','019f846e-6950-7188-871e-a42e435bdd7a','BM3 Ngâm Full 3','vlclone-251368-bm3-ngam-full-3','Đã tạo 3 TKQC | Bao add thẻ nhảy limit cao | Limit 50$ | Created:  Jul/2026',1.81000000,40000.00,379,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 ngam full 3',NULL),('019f846e-695c-7176-94e9-11cef5b7fc22','019f846e-66a7-7247-bb63-b9ebcf11be46','251369','019f846e-6950-7188-871e-a42e435bdd7a','BM3 Ngâm Full 4','vlclone-251369-bm3-ngam-full-4','Đã tạo 4 TKQC | Bao add thẻ nhảy limit cao | Limit 50$ | Created:  Jul/2026',2.26000000,50000.00,64,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 ngam full 4',NULL),('019f846e-695e-7036-ad2f-c301d49e258e','019f846e-66a7-7247-bb63-b9ebcf11be46','251371','019f846e-6950-7188-871e-a42e435bdd7a','BM3 XÁC MINH DOANH NGHIỆP FULL 3','vlclone-251371-bm3-xac-minh-doanh-nghiep-full-3','Đã tạo 3 TKQC | Bao add thẻ nhảy limit cao | Limit 50$ | BM Verify Business | Created:  Jul/2026',9.96000000,220000.00,329,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 xac minh doanh nghiep full 3',NULL),('019f846e-695f-7364-a083-3d574429ce14','019f846e-66a7-7247-bb63-b9ebcf11be46','251523','019f846e-6950-7188-871e-a42e435bdd7a','BM3 XÁC MINH DOANH NGHIỆP FULL 4','vlclone-251523-bm3-xac-minh-doanh-nghiep-full-4','Đã tạo 4 TKQC | Bao add thẻ nhảy limit cao | Limit 50$ | BM Verify Business | Created:  Jul/2026',11.32000000,250000.00,0,0,'2026-07-23 14:41:52','inactive',NULL,'[]','2026-07-21 04:27:36','2026-07-23 17:03:19','bm3 xac minh doanh nghiep full 4',NULL),('019f8a20-3956-701c-a194-13f1e5d1a781','019f829a-f708-7093-890d-4950e6ce2e66','10015','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 XÁC MINH DOANH NGHIỆP FULL 4 (Live 2 Tài Khoản)','ads7979-10015-bm3-xac-minh-doanh-nghiep-full-4-live-2-tai-khoan','Đã tạo 4 TKQC | Limit 50$ | Limit tăng theo chi tiêu cực nhanh | Created: Jul/2026',6.85000000,150000.00,0,0,'2026-07-22 07:08:46','inactive',NULL,'[]','2026-07-22 06:59:55','2026-07-23 18:41:39','bm3 xac minh doanh nghiep full 4 (live 2 tai khoan)',NULL),('019f8a20-395b-73d7-b77e-17b749708832','019f829a-f708-7093-890d-4950e6ce2e66','10014','019f82af-5c5e-7396-95a3-825ffab2f738','BM3 XÁC MINH DOANH NGHIỆP FULL 4 (Live 3 Tài Khoản)','ads7979-10014-bm3-xac-minh-doanh-nghiep-full-4-live-3-tai-khoan','Đã tạo 4 TKQC | Limit 50$ | Limit tăng theo chi tiêu cực nhanh | Created: Jul/2026',9.34362641,189000.00,0,0,'2026-07-23 18:41:38','active',NULL,'[]','2026-07-22 06:59:55','2026-07-23 18:41:38','bm3 xac minh doanh nghiep full 4 (live 3 tai khoan)',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('CjPGIYWYG1V0b84yOuu03eJmY4Os11QppdOo7fcE',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJyR3VMYndxN2d5TEdDOHM5UlJNU3ZIRkNWMHplRGJOR1VuV1BUWEdKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwIiwicm91dGUiOm51bGx9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784522068);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_purchases`
--

DROP TABLE IF EXISTS `supplier_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_purchases` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_order_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int unsigned NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `response_payload` longtext COLLATE utf8mb4_unicode_ci,
  `error` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_purchases_order_id_foreign` (`order_id`),
  KEY `supplier_purchases_order_item_id_foreign` (`order_item_id`),
  KEY `supplier_purchases_product_id_foreign` (`product_id`),
  KEY `supplier_purchases_supplier_id_status_index` (`supplier_id`,`status`),
  KEY `supplier_purchases_supplier_order_id_index` (`supplier_order_id`),
  CONSTRAINT `supplier_purchases_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_purchases_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_purchases_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `supplier_purchases_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_purchases`
--

LOCK TABLES `supplier_purchases` WRITE;
/*!40000 ALTER TABLE `supplier_purchases` DISABLE KEYS */;
INSERT INTO `supplier_purchases` VALUES ('019f902c-01fc-72ea-9f14-c10734add491','019f902c-01ec-715f-88d4-9c145fb6cb74','019f902c-01ed-7236-8669-19544cf54f9a','019f829a-f708-7093-890d-4950e6ce2e66','019f82af-5e5b-71f0-862c-8d15f88b57bb','10887',1,'succeeded','eyJpdiI6IndIUjByUEs3eEUzWWhPSm9iK1huWkE9PSIsInZhbHVlIjoiaUhlcFZFOXpzdlJwV21rd2RTaXBnWld4RFhnV0tRM3c0VFZSSXZMa2kwVzZPUjlCOUpINWVNWkhPalhLQzhjMWtUMDhGa05IVTNnTVlDZ1pGWjQ4YjZEcm9yZWNmZEt5VXlVZ1djdmRpNCtaRFBpNkZpbTZ0eEprOFpEWHIzL0xnaThacEVkbkt6aUFHdEJPaFY5cXdqcytJVnJzMWZDWTFKTkM3T25Yc1lIZzhQMmZTK25XN3dSRnFLbjNHU0swYWdyZDRZQlJJNFhteHNYVmRnQzdDLzQvc1phNThzaDhpcFhNL0plSWZQVUxXdUQzZDd0WVQ1cjRZTUtLdmdvbGhWdGdadkYvN1ZOUzd2anN6cnNyOGZKbjdHTHVQNnJwTlFFRXRVemV6RnFVMER0ejV6bFZiSEJMTVF0dFNkS2I5NTA1MjAvRUxTclJGUS9XNVJ1eWhkcmJrR1NxRXVsSWFaSjVBTWVNS2xqWmc5U3lBOGZWVW03WEtuZVRVRSt2bG9wbFRyMDFhWnAvVmVYKzd3SGhtSVZTTzhHSEtlQTNxUWRwUFAwOFFFQkd2azVtMUxNVm84SkFlVXVoeWM5RHluNTZOREdscFh3Tk5DYkZkZVZFODNPNXlEOU1DWkJtNW5kd2FFUEg4M291Mlc0QkluRzdwbVhodHdpVy9LaFlaSWFYRlNtWVRDOGV0VHJIL3hZQTk1bVNvblB2UmgyckgzL2hjMktGTlVaR3dMWEdmQXd6UnZHRndkNHRQQ1o5Wm1ISTBKQWFMS0UranR0akk0MGppOHB6Qi8zc2J6anZMb1pRQ2JhMFV2WStvbXFqczJ1SjNpaXBHOEZ1bUVOMGgrSmhEbFJIUEk4eklvZXdpbTdQSVpBT1hBNlBHdHp0TGExWHBIczBZT3Y5WHZCeVdDbEltZjI0NU16dERYeHpULzVZMEovUTVHSTBuOU9OdGxudTFLblNuMFY3cmlQZjIwdWRqN2tNRk90eWJnbEhnSEpGd2t3T3BLbGZKUTdRaU53eTFodFdQSk1aUUgvZi9aOTEzVVBkUXo0Tk91K1IwVkFjVXhuVW5STUxtQjF4eXNhYWNKOFhRbkdhOExEc0dZbGZQZVVxOGNsbGZLK2F2em9rUWo3YjQ2djloR0kwWmtZYWN4Q1R6YTg5NitPY1lDYWx5RGh5bHQwdzBHNWJLbGlxUVR4TVJmVUtvSklPdUtWdkRhbk9zckxzQkd3UGdvc2VQZFUwM2FlVzIrRXUxSWhLQ3VxaTA0bWNwaFBtcUJSVS9UdC9VazBTWFFobkdrS2dSdklJWVhocllTemZHUDlNMFh4SmgrdmlXNndONkFTV3BuWkwxSXRmUW00dUdxcWhVRFhpSzhVdThZcnY0UmkvVlR3WmxqM3Q3ak1IdW0rd1kyZWc2YThYaFNOa3ZBV0pLdkhOa2NwVkFRZDJSdTVIRllvWk5NYnJMdlgzMEtsSnFDa3Fzc1pnSkxySDlaRmd5eVlKRlVsd21FM1FESGhQWnozMmtuUmlMSlR1IiwibWFjIjoiOTQwMWQ1ZTc3YjhmMmMyZjBmYWRmMDM4ZjgxNzRmYzkwMzkyMzA3NDhiZTMwMzNlMWZlNGE3MTI3Zjk3Y2RjYyIsInRhZyI6IiJ9',NULL,'2026-07-23 18:10:31','2026-07-23 18:10:31'),('019f9049-2798-7257-8ac4-1427b4ca5ea8','019f9049-2760-735b-aa23-519943846b39','019f9049-276f-70f4-b3dd-cb47d4dbf0b3','019f829a-f708-7093-890d-4950e6ce2e66','019f82af-5e5b-71f0-862c-8d15f88b57bb','10892',1,'succeeded','eyJpdiI6Ijc5U1ZXL2h6VGNzSm52VXZYSFQ3eWc9PSIsInZhbHVlIjoiY2Z5ZCtScktCamtpTUZ5Z1ByZnRYNkZzY3hRblhYKzhMandzN29nZGVNR25GQlFXNlRmVk9BN0FyMVEyNjhRQmQzeURoMGM0L2dmaDdxMjBCRm1mdXl3RlNHbjd2L3lGTlk4Wkx0N2RSV1R6OWZLV2NxSm5FWERjQThuS0kxd01tTUg4MGdibXE1a0RVVjhreUlmaW94Y0tzWmtHWjRYUW5taGFhZnIzKzVRMWszakVMRGpyb0pnUEc4UitVeUpoc1dpNlBYME0rK3FvR0JaYTh2L0ZxZmcydGZ0UlAxM2FKTkdCbTdhRDNmL3lNM3lZRFF3RCtRRUVkS1I4K1NxTjhranRlQlRKWkQ5L1B6WjBIN2lsRVZFQVRmTWNzcGZuRW1VUm51bVl3UEpkaDhNUlBjOXRSMlBOS0dEb3VzZEQzbGNoYUN4d1ZrWmRpWVU5M2JyeWFnSXJWT1BjMFdaZm1IWWFaQTMrek52QnhteGZXSmFDZ01MRU5uQWcyU1dXQWd5Q2htOVBsRkdTRGxNZTV6MXRiaHA2ZlozbmxRUCthTjFwZmZNZmRlL1R3MTd2UVdTZ3V4b1NXV0N1YXhFR1MvUFRDZ3dWcm11TlFWaFdDUUVwaWNoc01PK3ZuL3lMOXJGSGg5THdFMnlOd3I1Nko4dWVRbHFhRGJiak13NytRWDFuSFpwMmJKdTZHTEQ1V1RVdFh5VW9zK2FsREM2R0s2VmQ1K0xrWVkrZklFWmdmKzhwUVVjZ1B2VlFkdGhzL0VtU3N6OW9hME1SQXR2TnhGOHRuUEE5d2IzaDJUb1dVV2FDVUZkNDhWczVBcjFzUlUrN0F1VzRKdjIzQk8zb2xKcHptUHlzelVXWXVRK25VUW00TjBqUnlnVE00N1ZtdVg3Y2NOQUlyTWRGV3hvS0dOc0VnQ0NqMStubVFWcjFuZ0pGNElMZ3FIdFVtRXF3T1Ywcko2UUdGMXQ5YTVrV1k1dk1qMzZEK3p6MjZlbFJ6ekRNMmxWeVpidEFla1VVOERuaXhKdjNvMEhOYTdoT0ZEWlhQVVBmWmlvc1U3aEFTcjBYbGJzNmhFS21TVndqbzM3TDk2djV4WVpobDFJNnlJVWxzbHloYmZidWZtLzBvbk51aXoyWmhXR0cvTko0WXRPMHFKZmI4SzVia0VxTmM1TWFmc3ZjY2tpN2NycnorSkdaUjEza21YZTdyb1NobkhQWFNyTFRqTUJmdkhlSE9TVGVIV05lRE9KcTFlbFFFemNlNFNScEVQbElyQVp6djJ3aHNkZ25TWnhJZjlnRVh1b043ajNsaDk5c0dEUEk4Sjg0TDVIUU1sV1AxTWQyNzdoK2VYL2lzdnY3UjV5b0V3aG15bit5eTZkZTI3R3pxRzA1aFBDUzNBRitUOEJJbkJVM3lJaEtGQTZORGxUNnZTaUpzQXY4UDlLRmY4L0hxcUxFNnFCWnJkVTBVWDNheHpqVHh0UUFJb0NRZ2dTYkNYaWNCMTFQVTFvPSIsIm1hYyI6IjE2ODE4OGFmNWVhZGE5ZDM3MzdhNjhjNDk4NTdmYzk5MDI0NWRhODUyZTRjMTVkZWEwMDY4NTVjYmViYjg0ZjQiLCJ0YWciOiIifQ==',NULL,'2026-07-23 18:42:21','2026-07-23 18:42:21');
/*!40000 ALTER TABLE `supplier_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catalog_driver` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'clone_store_v2',
  `api_key` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `products_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `import_out_of_stock` tinyint(1) NOT NULL DEFAULT '1',
  `auto_sync` tinyint(1) NOT NULL DEFAULT '0',
  `sync_interval_minutes` smallint unsigned NOT NULL DEFAULT '30',
  `price_adjustment_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `price_adjustment_value` decimal(15,2) NOT NULL DEFAULT '0.00',
  `last_synced_at` timestamp NULL DEFAULT NULL,
  `last_sync_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_sync_error` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES ('019f829a-f708-7093-890d-4950e6ce2e66','ads7979','ADS7979','https://ads7979.com','clone_store_v2','eyJpdiI6IjVkVGlENy84cVFPYVVQbW1kZENNc0E9PSIsInZhbHVlIjoiQk04a2Fid1V5WTBWeC9rOG1ZdDJYNGhodVRicjZaNjgzWGFoYzE3VktEZkpXVXNTYVFXMHlGSlc4cnZZQ2Q3TSIsIm1hYyI6ImUzMmYyMmZlNGUzZTg4YmUzYjRlY2U3ODRjOTMwMWU5ZjllZTQ2MDRjNTQwNDQ2NzQ4Y2I2N2JjOWFkYTc0NWEiLCJ0YWciOiIifQ==',1,1,1,1,30,'percent',30.00,'2026-07-23 18:41:39','success',NULL,'2026-07-20 19:57:01','2026-07-23 18:41:39'),('019f846e-66a7-7247-bb63-b9ebcf11be46','vlclone','VLClone','https://vlclone.com','clone_store_v2','eyJpdiI6Ik5HZzZ6cVBKaFZIbjFKaEtiY3JialE9PSIsInZhbHVlIjoiZGJmb3l5aDBKY0Z3QnJHcjVGUFFiNU5XM3JaU3RVMjZYTTlqeXVHTFZ5dWVaL2Z4ckh3TWtrTkl0QU9sWXI1NSIsIm1hYyI6ImE5NmI3MmJkYWEyYmZmYTNmODY2YzE1NmQ2YWRiZjYwYjM4ZGNiZDgyYzg4MWFhYWIyNzg2YTQzOTZiNmJhOWQiLCJ0YWciOiIifQ==',0,0,1,1,30,'percent',20.00,'2026-07-23 14:41:52','success',NULL,'2026-07-21 04:27:35','2026-07-23 17:03:19');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('admin_binance_id','63596652','Binance ID nhận tiền nạp của admin','2026-07-19 18:41:52','2026-07-19 18:44:07'),('admin_wallet_address','0xAB4a22a64bBC1Ca0445758C2Ee66a4cB2b644444','Địa chỉ ví USDT nhận tiền nạp của admin (BEP20)','2026-07-19 18:41:54','2026-07-19 18:44:07'),('binance_api_key','eyJpdiI6IlhxNy9iZU4yajlTbU5rVFhDR0Rac1E9PSIsInZhbHVlIjoiTDdDeTRtbXFPZ2g2N2VLRzYySHJMVDZjZTNITElDeGxaQWFyMjJjelNLMHUzeFFkTGE1d1k2N2l0Sys0TWdVYStOd1RzOE1OZUUzbC9LMzArQzJETS9RSUtQaHh2QW03SjFsN0NETTZ2V2c9IiwibWFjIjoiMmQ3MjE5YmI1ZTgwNWUwN2M2NGRiZDg2ODRiOWU3OTQ0MDQ2YzQ4NTQzNGMyNDEyZGUzZjY4NWMwNWNmZTRkNiIsInRhZyI6IiJ9','Binance API Key của admin để đối soát nạp tiền qua Binance ID','2026-07-19 18:41:52','2026-07-19 18:44:07'),('binance_api_secret','eyJpdiI6IlA0NjZnRDY4dy9lMXV6akFxSFBhREE9PSIsInZhbHVlIjoiMldGbjdWMzFmdlpkOU5yR2NJb21TZW93NmpqUWVDQzQzRDQ3N3k1RDBDeHNvYnJpb0d3Sk8vbWpuQ2lRWTVVaU9XK243ZWZCYytGdW5vZXFGMTVySEFFYm9MUUNWREJnR013czh4REVjRkU9IiwibWFjIjoiNGExNjIwZTUyNzJhZjhiYzQ3MGEzNzA0MTU0ODZjYzRkZWM2NTg4ZTJkZjZhMDFhNjFlMzkyYWY4ZDZiMDc3ZiIsInRhZyI6IiJ9','Binance API Secret của admin để đối soát nạp tiền qua Binance ID','2026-07-19 18:41:52','2026-07-19 18:44:07'),('scanner_api_key','eyJpdiI6IkxhSWVyWlFndVVKVmxQazFWSlZQZ1E9PSIsInZhbHVlIjoiQXVocnlkcWtzTC9mSkZxRGJVdHM4VXBIQ2w2MDR4OUtXRWJ0bXB0VjJzUVMwQlM3L2JHMWxzMDJHSTVuNEI4TjNrSERJRWVvN0pmdE1YbUZiZWw1RWE5eDU4Sm9menhvamlKZHRQQ01XbHBGQUNaNlJPQ0hRTnpYdjd3cnlMd1dsVVlDb3RaVTlkUGxUUGszQTNIRVJmbjRmV200V0dCdlRmNUx2dkNnRHJZRG0vbjUydm1od2dqRG1xVFJCd05OZ2l0YzllQS9FakVRODRrV253SEs3ZG1VeXVMeFk0VUE4R0RnaWNtMHNoK0lNdmUzZDdwNTk4SUFpeTdXOXFLT3VFbDdPeUVGUk45R3ZZanN4anl6MjBnMFdVeGZDRitvM2thblFPUTZDcElqbmo0NnJ1bnZwRW1TeUFQMFlQSm9GYzQ2TkJvQ1dkUzN5emFLYUJ2ZjR0L1EyTk9SdWpaeENKYzFsdHhmL244QytIcGRya1llUFJBUnk1OTl0WlRQREZIc1hpVytvdjMxT1FCRXl0eXR2YmxEcStVNFBRVDJSQW9xQ2lhRG9DdWYwWkZaNS9ZR3h1NGc5U0hGdXlweiIsIm1hYyI6ImQxZjc3ZjIzMzlkZjE4MTA4Y2U2MzVkZDg0MmEzMDk3YTJlOTczNjg0ZWYzZDVkMmNjNzZiOTE2MjE4ZWVhNWQiLCJ0YWciOiIifQ==','API Key của Moralis để đối soát giao dịch nạp tiền tự động','2026-07-19 18:41:54','2026-07-19 18:44:07'),('token_cleanup_days','7','Số ngày lưu trữ login tokens trước khi tự động dọn dẹp','2026-07-19 18:41:54','2026-07-19 18:41:54'),('usdt_exchange_rate','0','0 = dynamic CoinGecko USDT/VND rate','2026-07-19 18:41:54','2026-07-20 20:08:29');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sessions` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_sessions_user_id_index` (`user_id`),
  KEY `user_sessions_last_activity_at_index` (`last_activity_at`),
  CONSTRAINT `user_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
INSERT INTO `user_sessions` VALUES ('09a62ebe-0ef4-4ee6-9e9c-3ed5abbfb5cf','019f7d2f-cf44-723f-8c30-13b7ea78dadb','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','Google Chrome (Windows)','2026-07-24 04:20:39','2026-07-24 04:20:18','2026-07-24 04:20:39'),('2df2c59e-72a5-43b5-8a81-087e1fc80e5a','019f7d2f-cf44-723f-8c30-13b7ea78dadb','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','Google Chrome (Windows)','2026-07-24 04:21:37','2026-07-24 04:21:25','2026-07-24 04:21:37'),('3a8efb38-0720-4b79-8568-904f4f3a7af3','019f7d2f-cf44-723f-8c30-13b7ea78dadb','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','Google Chrome (Windows)','2026-07-24 04:19:56','2026-07-24 03:51:00','2026-07-24 04:19:56'),('8b38e26a-b771-487e-b0b6-a2bd495726ee','019f7d2f-cf44-723f-8c30-13b7ea78dadb','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','Google Chrome (Windows)','2026-07-24 03:50:34','2026-07-23 14:13:59','2026-07-24 03:50:34'),('c4fc821e-a9af-4978-a271-bd4a54e2e867','019f7d2f-cf44-723f-8c30-13b7ea78dadb','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','Google Chrome (Windows)','2026-07-24 05:29:52','2026-07-24 04:22:14','2026-07-24 05:29:52');
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uid` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','customer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'customer',
  `balance` decimal(20,8) NOT NULL DEFAULT '0.00000000',
  `refresh_token_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token_expired_at` timestamp NULL DEFAULT NULL,
  `token_version` bigint unsigned NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` text COLLATE utf8mb4_unicode_ci,
  `api_key_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google2fa_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google2fa_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `normalized_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_api_key_hash_unique` (`api_key_hash`),
  UNIQUE KEY `users_uid_unique` (`uid`),
  KEY `users_name_index` (`name`),
  KEY `users_refresh_token_hash_index` (`refresh_token_hash`),
  KEY `users_normalized_name_index` (`normalized_name`),
  KEY `users_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('019f7d2f-cf44-723f-8c30-13b7ea78dadb','27521044','admin','Admin Hệ thống','admin@isocalmarket.com',NULL,NULL,'$2y$10$Yvj0V0FiS12COpg8OsohsOrYG79yTmmh33oL9UoXC2RAt4WFZE72m','admin',942.58335196,'075fd92f5d1ebe26b1d46b8839a0b45aeb2e2f381e0706491a10b8c92fbd0535','2026-07-31 05:25:29',0,NULL,'eyJpdiI6IkhCUUNhM1h4Q2RZbS85VnBqdFZnRGc9PSIsInZhbHVlIjoiRkk0N3dEMlQ2QUtsczR0anhtWjNTM3hqVy96QVVrL2xSNTZrNnJUVEJndTIyb1JkbVl5SytreS96M2loVUcvZSIsIm1hYyI6IjQwNTliMWI0NTI4MTNlMTlkZjVjMDhhNzJhNGRmMzk1NTgzZWFiMTBmZDRmMDZlZjcyY2YwMzQ4M2NlOWE5NzkiLCJ0YWciOiIifQ==','eea9313b914c959e79457757c6aeed71bd8cc8e836c12920f55e5a609a34217a','ADDMPJIXJV26U3X6',0,'2026-07-19 18:41:53','2026-07-24 05:25:29','admin he thong','active'),('019f8478-5cb6-71c0-88a4-19a78f002dfc','27521046','tiendatmagic','Đạt Tiến','tiendatmagic8@gmail.com',NULL,NULL,'$2y$12$qDZ2uH8iSuTcFWiRBRbS/upeiWEtTX4h2gWHrI1OiwDTBjTExGCrC','customer',0.00000000,NULL,NULL,2,NULL,'eyJpdiI6IlFDRlZxYXJyUEFqK0t6QjNKR3hUNFE9PSIsInZhbHVlIjoiVVU2cmRtd1A3ekQzeTBZN3FhMTN1UHMwMy80bDZnaWtGQjJ4SUxaTG5aU3VmZ1dSa1lEUzhHK0dPRy9taDVpayIsIm1hYyI6IjdhZThiZWQxYzQ2NzA3ODdiNmRhNmVhYmIzMjFhNmM3OWI5YzRjNmJhODZjZTU4MmQzNmIxZTg1ZDFiY2E1NjMiLCJ0YWciOiIifQ==','ef62d397f0b1e729fc2f02012bb8889295447e5325bb128f596aa427b694ff8d',NULL,0,'2026-07-21 04:38:28','2026-07-23 05:39:23','dat tien','active'),('019f8489-b459-702d-956a-a183467607c4','27521047','tiendatmagic8','tiendatmagic8','tiendatmagic88@gmail.com',NULL,NULL,'$2y$12$tIY9uQoea6I8Dkw2Kemt1O3uKmsV/b0wjt1qZWp7LeDpVjAEgFhH6','customer',0.00000000,NULL,NULL,2,NULL,NULL,NULL,'RCG4I2JFXEHUXP2B',1,'2026-07-21 04:57:24','2026-07-24 04:51:41','tiendatmagic8','active');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warranty_policies`
--

DROP TABLE IF EXISTS `warranty_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warranty_policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bm',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'accepted',
  `content_vi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_content_vi` text COLLATE utf8mb4_unicode_ci,
  `sub_content_en` text COLLATE utf8mb4_unicode_ci,
  `tag_vi` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_en` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_color` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blue',
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `warranty_policies_category_type_is_active_index` (`category`,`type`,`is_active`),
  KEY `warranty_policies_sort_order_index` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warranty_policies`
--

LOCK TABLES `warranty_policies` WRITE;
/*!40000 ALTER TABLE `warranty_policies` DISABLE KEYS */;
INSERT INTO `warranty_policies` VALUES (1,'bm','accepted','BM bị lỗi hoặc Không nhận được link truy cập ngay sau khi bàn giao','BM error or failed to receive access link right after delivery',NULL,NULL,'24 giờ','24 hours','blue',1,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(2,'bm','accepted','BM bị chết Trước khi KHÁCH HÀNG sử dụng','BM dead BEFORE customer usage',NULL,NULL,'24 giờ','24 hours','blue',2,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(3,'bm','accepted','BM đã xác minh doanh nghiệp (Business Verification)','Business Verified BM lost verification status',NULL,NULL,'07 ngày','07 days','emerald',3,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(4,'bm','accepted','Giới hạn chi tiêu hàng ngày bị giảm — áp dụng cho BM có ghi rõ hoặc thoả thuận ở mô tả sản phẩm','Daily spending limit dropped (applicable for BMs explicitly specified in description)',NULL,NULL,'07 ngày','07 days','emerald',4,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(5,'bm','rejected','BM bị vô hiệu hóa / die sau khi khách đã lên camp quảng cáo hoặc add thẻ thanh toán','BM disabled / dead after creating campaigns or adding payment cards',NULL,NULL,'Từ chối','Rejected','rose',1,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(6,'bm','rejected','Quá thời hạn bảo hành quy định (24 giờ đối với BM thường, 07 ngày đối với BM xác minh)','Exceeded warranty time limit (24h for normal BM, 07 days for Verified BM)',NULL,NULL,'Hết hạn','Expired','amber',2,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(7,'bm','rejected','Khách hàng tự ý kích out QTV gốc hoặc thay đổi thông tin BM khi chưa kiểm tra thành công','Customer removed original admin or changed BM info before verification',NULL,NULL,'Từ chối','Rejected','rose',3,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(8,'bm','rejected','BM bị tụt giới hạn chi tiêu do chạy quảng cáo vi phạm chính sách Facebook hoặc bùng tiền','Daily limit reduced due to policy violation ads or unpaid balance',NULL,NULL,'Vi phạm','Violation','rose',4,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(9,'via','accepted','Login lần đầu thất bại: sai UID, sai Mật khẩu, sai mã 2FA, checkpoint 282 sẵn','First login failure: wrong UID, wrong Password, wrong 2FA, pre-existing 282 checkpoint',NULL,NULL,'Lần đầu','First login','amber',1,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(10,'via','accepted','Via mô tả \"Checkpoint Mail\" — bảo hành checkpoint 956 kể cả sau khi khách đã sử dụng','Via with \"Mail Checkpoint\" description — 956 checkpoint warranty after usage','(Yêu cầu: chưa thay đổi email, Chưa bật 2FA)','(Requirement: email unchanged, 2FA not enabled)','07 ngày','07 days','emerald',2,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(11,'via','accepted','Tài khoản Facebook người dùng thật/Clone bị vô hiệu hóa tài khoản cá nhân, tài khoản trả Trước hoặc hạn chế quảng cáo từ Trước thời điểm mua','Personal account disabled or ad restricted prior to purchase time',NULL,NULL,'Có sẵn','Pre-existing','amber',3,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(12,'via','accepted','Thông tin Via Không đúng với mô tả khi mua — vui lòng Không sử dụng để được bảo hành','Via specs mismatched with description — please do not use to claim warranty',NULL,NULL,'Không dùng','Do not use','rose',4,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(13,'via','rejected','Tài khoản dính checkpoint / die sau khi khách đã thay đổi Mật khẩu, Email hoặc Mã 2FA','Account checkpointed / dead after password, email, or 2FA changed',NULL,NULL,'Từ chối','Rejected','rose',1,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(14,'via','rejected','Quá thời hạn bảo hành mua hàng hiển thị tại mục Lịch Sử Mua Hàng','Exceeded purchase warranty duration shown in Order History',NULL,NULL,'Hết hạn','Expired','amber',2,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(15,'via','rejected','Đăng nhập trên thiết bị bẩn, IP đen / Proxy rác bị Facebook quét checkpoint hàng loạt','LoggedIn on dirty device, blacklisted IP / poor proxy causing mass checkpoint',NULL,NULL,'Từ chối','Rejected','rose',3,1,'2026-07-24 04:09:29','2026-07-24 04:09:29'),(16,'via','rejected','Sử dụng tài khoản vào các mục đích vi phạm pháp luật (cờ bạc, lừa đảo, spam độc hại)','Account used for illegal activities (gambling, scamming, harmful spam)',NULL,NULL,'Vi phạm','Violation','rose',4,1,'2026-07-24 04:09:29','2026-07-24 04:09:29');
/*!40000 ALTER TABLE `warranty_policies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-24 12:29:53
